#include "CodecLibrary.h"

namespace BitmapGraphics
{
    void CodecLibrary::registerEncoder(HBitmapEncoder hbitmapEncoder)
    {
        _encoders.push_back(std::move(hbitmapEncoder));
    }

    void CodecLibrary::registerDecoder(HBitmapDecoder hbitmapDecoder)
    {
        _decoders.push_back(std::move(hbitmapDecoder));
    }

    HBitmapEncoder CodecLibrary::createEncoder(const std::string& mimeType, HBitmapIterator bitmapIterator)
    {
        for (const auto& encoder : _encoders)
        {
            if (encoder->getMimeType() == mimeType)
            {
                return encoder->clone(std::move(bitmapIterator));
            }
        }

        throw std::runtime_error{ "No encoder for " + mimeType };
    }

    HBitmapDecoder CodecLibrary::createDecoder(const std::string& mimeType, std::istream& sourceStream)
    {
        for (const auto& decoder : _decoders)
        {
            if (decoder->getMimeType() == mimeType)
            {
                return decoder->clone(sourceStream);
            }
        }

        throw std::runtime_error{ "No decoder for " + mimeType };
    }

    HBitmapDecoder CodecLibrary::createDecoder(std::istream& sourceStream)
    {
        const int ChunkSize = 100;

        // get first chunk to use for type determination
        char firstChunk[ChunkSize]{};
        sourceStream.get(firstChunk, ChunkSize);

        // reposition stream back to beginning
        sourceStream.clear();
        sourceStream.seekg(std::istream::beg);

        for (const auto& decoder : _decoders)
        {
            if (decoder->isSupported(firstChunk))
            {
                return decoder->clone(sourceStream);
            }
        }

        throw std::runtime_error{ "No decoder for source stream" };
    }
}
