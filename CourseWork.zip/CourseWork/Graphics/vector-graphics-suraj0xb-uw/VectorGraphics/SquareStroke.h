#pragma once

#include "IStroke.h"
#include <memory>
#include "SquarePen.h"

namespace BitmapGraphics
{
	class SquareStroke final : public IStroke
	{
    public:
        SquareStroke();
        explicit SquareStroke(std::string& tip, int size, Color color);

        void setSize(int size) override;
        int getSize() const override;
        void setColor(const Color& color) override;
        Color getColor() const override;
        HPen createPen(const HCanvas& canvas) override;

    private:
        int _size;
        Color _color;
	};
}
