#pragma once

#include <string>
#include <fstream>
#include <memory>
#include <iostream>

#include "Interface.h"
#include "Bitmap.h"
#include "BitmapIterator.h"
#include "WindowsBitmapHeader.h"

namespace BitmapGraphics
{
    class WindowsBitmapEncoder : public IBitmapEncoder
    {
    public:
        WindowsBitmapEncoder() = default;
        virtual ~WindowsBitmapEncoder() =default;

        WindowsBitmapEncoder(const WindowsBitmapEncoder& ) =default;
        WindowsBitmapEncoder(WindowsBitmapEncoder&& ) =default;
        WindowsBitmapEncoder& operator=(const WindowsBitmapEncoder& ) =default;
        WindowsBitmapEncoder& operator=(WindowsBitmapEncoder&& ) =default;

        HBitmapEncoder clone(HBitmapIterator bitmapIterator) override;
        void encodeToStream(std::ostream& destinationStream) override;
        const std::string& getMimeType() const override { return MimeType; };

    private:
        HBitmapIterator _bitmapIter; 

        void writePadBytes(std::ostream& ) const;
    };
}
