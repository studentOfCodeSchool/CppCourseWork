#pragma once

#ifndef __DEF_BASIC_CANVAS
#define __DEF_BASIC_CANVAS

#include <iostream>
#include <memory>
#include <map>

#include "ICanvas.h"
#include "Color.h"
#include "Point.h"
#include "Interface.h"





namespace BitmapGraphics
{
    class BasicCanvas final : public ICanvas
    {
    public:
        BasicCanvas();
        ~BasicCanvas() =default;

        explicit BasicCanvas(int width, int hight);
        explicit BasicCanvas(int width, int height, BitmapGraphics::Color c);

        BasicCanvas(const BasicCanvas&) = default;
        BasicCanvas(BasicCanvas&&) = default;
        BasicCanvas& operator=(const BasicCanvas&) = default;
        BasicCanvas& operator=(BasicCanvas&&) = default;

        void setPixelColor(const VG::Point, const Color color) override;
        Color getPixelColor(const VG::Point) const override;
        int getWidth() const override { return _width;}
        int getHeight() const override { return _height; }
        HBitmapIterator createBitmapIterator() const override;

    private:
        int _width;
        int _height;
        Color _backgroundColor;
        HBitmapIterator _hBitmapIter = { 0 };
        std::map<VG::Point, Color> _canvasPixels;
        HBitmap _hBitmap;
    };

    using HCanvas = std::shared_ptr<BasicCanvas>;
}

#endif 
