#pragma once

#include <list>
#include <string>

#include "PlacedGraphic.h"
#include <iterator>

namespace Framework
{
	using PlacedGraphicCollection = std::list<PlacedGraphic>;
	using PlacedGraphicCollectionIterator = std::list<PlacedGraphic>::iterator;


	class Layer
	{
	public:
		typedef PlacedGraphicCollectionIterator PlacedGraphicIterator;

		Layer(const std::string& name) : _name(name) { }
		~Layer() = default;

		Layer(const Layer& src) = default;
		Layer(Layer&& src) = default;
		Layer& operator=(const Layer& rhs) = default;
		Layer& operator=(Layer&& rhs) = default;

		bool operator==(const Layer& rhs) const;

		const std::string& getAlias() const { return _name; }

		void pushBack(const PlacedGraphic& graphic);
		void remove(const PlacedGraphic& graphic);



		PlacedGraphicCollectionIterator begin();
		PlacedGraphicCollectionIterator end();

	private:
		std::string _name;
		PlacedGraphicCollection _graphics;
	};
}
