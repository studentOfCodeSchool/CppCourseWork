#include "Layer.h"

namespace Framework
{
	bool Layer::operator==(const Layer& rhs) const
	{
		if (_name.compare(rhs._name) == 0)
		{
			if (_graphics == rhs._graphics)
				return true;
		}

		return false;
	}

	void Layer::pushBack(const PlacedGraphic& graphic)
	{
		_graphics.push_back(graphic);
	}

	void Layer::remove(const PlacedGraphic& graphic)
	{
		_graphics.remove(graphic);
	}

	PlacedGraphicCollectionIterator Layer::begin()
	{
		return _graphics.begin();
	}

	PlacedGraphicCollectionIterator Layer::end()
	{
		return _graphics.end();
	}
}
