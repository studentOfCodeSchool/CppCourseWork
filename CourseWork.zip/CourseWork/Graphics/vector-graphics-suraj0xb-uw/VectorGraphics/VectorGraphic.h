#pragma once

#include "Point.h"
#include "IStroke.h"
#include "Color.h"
#include <vector>
#include <memory>
#include <string>
#include "SquareStroke.h"

namespace VG
{
	class Point;
	using Points = std::vector<Point>;

	class VectorGraphic
	{
	public:
		enum class ShapeStyle { Open, Closed };

		VectorGraphic() {  }
		~VectorGraphic() = default;

		VectorGraphic(const VectorGraphic& ) = default;
		VectorGraphic(VectorGraphic&& ) = default;

		VectorGraphic& operator=(const VectorGraphic& ) = default;
		VectorGraphic& operator=(VectorGraphic&&) = default;

		void addPoint(const Point& p);
		void addPoint(Point&& p);
		void removePoint(const Point& p);
		void erasePoint(int index);

		void openShape();
		void closeShape();

		bool isOpen() const;
		bool isClosed() const;

		int getWidth() const;
		int getHeight() const;

		size_t getPointCount() const;
		const Point& getPoint(int index) const;

		void setStroke(std::string tip, int size, BitmapGraphics::Color color);
		BitmapGraphics::HStroke getStroke() const;

		bool operator==(const VectorGraphic&) const;
		bool operator!=(const VectorGraphic&) const;

		friend std::ostream& operator<<(std::ostream& os, const VectorGraphic& vg);

	private:
		Points myPath;
		BitmapGraphics::HStroke myStroke;
		ShapeStyle myShapeStyle{ ShapeStyle::Closed };
	};
}
