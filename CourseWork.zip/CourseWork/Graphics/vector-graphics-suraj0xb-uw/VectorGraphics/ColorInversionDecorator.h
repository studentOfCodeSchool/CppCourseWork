#pragma once

#include "BitmapIteratorDecorator.h"

namespace BitmapGraphics
{
    class ColorInversionDecorator: public IBitmapIterator
    {
    public:
        ColorInversionDecorator(HBitmapIterator);
        virtual ~ColorInversionDecorator() =default;

        ColorInversionDecorator(const ColorInversionDecorator& ) =default;
        ColorInversionDecorator(ColorInversionDecorator&& ) =default;
        ColorInversionDecorator& operator=(const ColorInversionDecorator& ) =default;
        ColorInversionDecorator& operator=(ColorInversionDecorator&& ) =default;

        ScanLine& nextScanLine() override;
        bool isEndOfImage() override;
        void nextPixel() override;
        bool isEndOfScanLine() override;
        Color getColor() override;
        uint32_t getBitmapWidth() override;
        uint32_t getBitmapHeight() override;

    private:
        HBitmapIterator _originalIterator;
    };
}