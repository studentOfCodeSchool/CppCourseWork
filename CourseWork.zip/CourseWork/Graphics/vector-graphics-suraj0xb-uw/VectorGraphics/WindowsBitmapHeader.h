#pragma once

// #include <sstream>
#include <fstream>
#include <vector>
#include <memory>

namespace BitmapGraphics
{
	typedef struct fileHeader
	{
		unsigned char firstIdentifier;
		unsigned char secondIdentifier;
		uint32_t fileSize;
		uint32_t reserved;
		uint32_t rawImageByteOffset;
	} FileHeader;

	typedef struct infoHeader
	{
		uint32_t infoHeaderBytes;
		uint32_t bitmapWidth;
		uint32_t bitmapHeight;
		uint16_t numberOfPlanes;
		uint16_t bitsPerPixel;
		uint32_t compressionType;
		uint32_t compressedImageSize;
		uint32_t horizontalPixelsPerMeter;
		uint32_t verticalPixelsPerMeter;
		uint32_t numberOfColors;
		uint32_t numberOfImportantColors;
	} InfoHeader;


	class WindowsBitmapHeader
	{
	public:
		WindowsBitmapHeader(std::istream& fs);
		WindowsBitmapHeader(int width, int height);
		WindowsBitmapHeader();
		~WindowsBitmapHeader() = default;

		WindowsBitmapHeader(const WindowsBitmapHeader&) = default;
		WindowsBitmapHeader(WindowsBitmapHeader&&) = default;
		WindowsBitmapHeader& operator=(const WindowsBitmapHeader&) = default;
		WindowsBitmapHeader& operator=(WindowsBitmapHeader&&) = default;

		unsigned char getFirstIdentifier() { return (*_fileHeader).firstIdentifier; }
		unsigned char getSecondIdentifier() { return (*_fileHeader).secondIdentifier; }
		uint32_t getFileSize() { return (*_fileHeader).fileSize; }
		uint32_t getReserved() { return (*_fileHeader).reserved; }
		uint32_t getRawImageByteOffset() { return (*_fileHeader).rawImageByteOffset; }
		//uint32_t getNumberOfPadBytes() { return (*_fileHeader).padBytes; }

		uint32_t getBitmapWidth() { return (*_infoHeader).bitmapWidth; }
		uint32_t getBitmapHeight() { return (*_infoHeader).bitmapHeight; }
		uint32_t getInfoHeaderBytes() { return (*_infoHeader).infoHeaderBytes; }
		uint32_t getNumberOfPanes() { return (*_infoHeader).numberOfPlanes; }
		uint32_t getBitsPerPixel() { return (*_infoHeader).bitsPerPixel; }
		uint32_t getCompressionType() { return (*_infoHeader).compressionType; }
		uint32_t getCompressedImageSize() { return (*_infoHeader).compressedImageSize; }
		uint32_t getHoriztonalPixelPerMeter() { return (*_infoHeader).horizontalPixelsPerMeter; }
		uint32_t getVerticalPixelPerMeter() { return (*_infoHeader).verticalPixelsPerMeter; }
		uint32_t getNumberOfColors() { return (*_infoHeader).numberOfColors; }
		uint32_t getNumberOfImportantColors() { return (*_infoHeader).numberOfImportantColors; }

		void write(std::ostream&);
		void readFileHeader(std::istream&);
		void readInfoHeader(std::istream&);

	private:
		std::shared_ptr<FileHeader> _fileHeader;
		std::shared_ptr<InfoHeader> _infoHeader;
	};

	typedef std::shared_ptr<WindowsBitmapHeader> HWindowsBitmapHeader;
}
