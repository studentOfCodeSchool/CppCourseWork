#include "BitmapIteratorDecorator.h"

namespace BitmapGraphics
{
    BitmapIteratorDecorator::BitmapIteratorDecorator(HBitmapIterator iter) : _hBitmapIterator(iter)
    {
    }

    ScanLine& BitmapIteratorDecorator::nextScanLine()
    {
        return _hBitmapIterator->nextScanLine();
    }

    bool BitmapIteratorDecorator::isEndOfImage()
    {
        return _hBitmapIterator->isEndOfImage();
    }

    void BitmapIteratorDecorator::nextPixel()
    {
        return _hBitmapIterator->nextPixel();
    }

    bool BitmapIteratorDecorator::isEndOfScanLine()
    {
        return _hBitmapIterator->isEndOfScanLine();
    }

    Color BitmapIteratorDecorator::getColor()
    {
        return _hBitmapIterator->getColor();
    }

    uint32_t BitmapIteratorDecorator::getBitmapWidth()
    {
        return _hBitmapIterator->getBitmapWidth();
    }

    uint32_t BitmapIteratorDecorator::getBitmapHeight()
    {
        return _hBitmapIterator->getBitmapHeight();
    }
}
