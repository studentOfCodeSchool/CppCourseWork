#include "ColorInversionDecorator.h"

namespace BitmapGraphics
{
    ColorInversionDecorator::ColorInversionDecorator(HBitmapIterator iter) : _originalIterator(iter)
    {
    }

    ScanLine& ColorInversionDecorator::nextScanLine()
    {
        return _originalIterator->nextScanLine();
    }

    bool ColorInversionDecorator::isEndOfImage()
    {
        return _originalIterator->isEndOfImage();
    }

    void ColorInversionDecorator::nextPixel()
    {
        return _originalIterator->nextPixel();
    }

    bool ColorInversionDecorator::isEndOfScanLine()
    {
        return _originalIterator->isEndOfScanLine();
    }

    uint32_t ColorInversionDecorator::getBitmapWidth()
    {
        return _originalIterator->getBitmapWidth();
    }

    uint32_t ColorInversionDecorator::getBitmapHeight()
    {
        return _originalIterator->getBitmapHeight();
    }

    Color ColorInversionDecorator::getColor()
    {
        Color c = _originalIterator->getColor();
        Color newColor(~c.getRed(), ~c.getGreen(), ~c.getBlue());
        return newColor;
    }
}
