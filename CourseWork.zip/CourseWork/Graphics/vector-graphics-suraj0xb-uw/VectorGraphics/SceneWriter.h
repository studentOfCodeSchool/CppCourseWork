#pragma once

#include "XmlReader.h"

namespace Framework
{
	class SceneWriter
	{
	public:
		static Xml::HElement writeScene(Scene& scene);

	private:
		static std::shared_ptr<tinyxml2::XMLDocument> _doc;
	};
}
