#include "Element.h"

#include <memory>
#include <stdexcept>

namespace Xml
{
	HElement Element::operator [](int index) const
	{
		size_t i = index;
		auto elementList = getChildElements();
		if (i < elementList.size())
		{
			int count = 0;
			auto iter = elementList.begin();
			while (iter != elementList.end())
			{
				if (count == i)
				{

					HElement hElement = *iter;
					return hElement;
				}

				++count;
				++iter;
			}
		}

		throw std::out_of_range("Index out of range");
	}

	std::string Element::getName() const
	{
		return _xmlElement->Name();
	}

	AttributeMap Element::getAttributes() const
	{
		auto attributeMap = std::make_shared< std::map<std::string, std::string> >();

		const tinyxml2::XMLAttribute* xmlAttributeIter = _xmlElement->FirstAttribute();
		while (xmlAttributeIter != nullptr)
		{
			std::string name(xmlAttributeIter->Name());
			std::string value(xmlAttributeIter->Value());
			attributeMap->insert(std::pair<std::string, std::string>(name, value));

			xmlAttributeIter = xmlAttributeIter->Next();
		}

		return *(attributeMap.get());
	}

	ElementList Element::getChildElements() const
	{
		auto elementList = std::make_shared< std::vector<std::shared_ptr<Element> > >();

		const tinyxml2::XMLElement* xmlElementIter = _xmlElement->FirstChildElement();
		while (xmlElementIter != nullptr)
		{
			//tinyxml2::XMLElement* element = xmlElementIter->ToElement();
			std::shared_ptr<Element> childElement = std::make_shared<Element>(xmlElementIter);
			elementList->push_back(childElement);

			xmlElementIter = xmlElementIter->NextSiblingElement();
		}

		return *(elementList.get());
	}

	std::string Element::getAttribute(const std::string str)
	{
		std::string value = "";
		const char* retStr = _xmlElement->Attribute(str.c_str());
		if (retStr != nullptr)
		{
			std::string temp(retStr);
			value = temp;
		}
		return value;
	}
}
