#include "BitmapIterator.h"

#include <exception>

namespace BitmapGraphics
{
    BitmapIterator::BitmapIterator(HBitmap hBitmap)
    {
        _hBitmap = hBitmap;

        _iterLine = _hBitmap->begin();
        _iterLineEnd = _hBitmap->end();

        if (_hBitmap->getHeight() > 0)
        {
            _iterPix = _iterLine->begin();
            _iterPixEnd = _iterLine->end();
        }
    }

    ScanLine& BitmapIterator::nextScanLine()
    {
        ++_iterLine;
        _iterPix = _iterLine->begin();
        _iterPixEnd = _iterLine->end();
        return *_iterLine;
    }

    bool BitmapIterator::isEndOfImage()
    {
        if (_hBitmap->getHeight() <= 0)
            return true;

        return ((_iterLine == _iterLineEnd)) ? true : false;
    }

    void BitmapIterator::nextPixel()
    {
        ++_iterPix;
    }

    bool BitmapIterator::isEndOfScanLine()
    {
        return (_iterPix == _iterPixEnd) ? true : false;
    }

    Color BitmapIterator::getColor()
    {
        return *(_iterPix);
    }

    uint32_t BitmapIterator::getBitmapWidth() 
    {
        return _hBitmap->getWidth();
    }

    uint32_t BitmapIterator::getBitmapHeight()
    {
        return _hBitmap->getHeight();
    }
}
