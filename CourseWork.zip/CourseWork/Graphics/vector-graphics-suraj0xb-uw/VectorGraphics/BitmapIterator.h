#pragma once

#include <memory>

#include "Interface.h"
#include "Bitmap.h"

namespace BitmapGraphics
{
    class BitmapIterator : public IBitmapIterator
    {
    public:
        BitmapIterator() =default;
        virtual ~BitmapIterator() =default;

        BitmapIterator(const BitmapIterator& ) =default;
        BitmapIterator(BitmapIterator&& ) =default;
        BitmapIterator& operator=(const BitmapIterator& ) =default;
        BitmapIterator& operator=(BitmapIterator&& ) =default;

        BitmapIterator(HBitmap );

        virtual ScanLine& nextScanLine() override;
        virtual bool isEndOfImage() override;
        virtual void nextPixel() override;
        virtual bool isEndOfScanLine() override;
        virtual Color getColor() override;
        virtual uint32_t getBitmapWidth() override;
        virtual uint32_t getBitmapHeight() override;

    private:
        HBitmap _hBitmap;
        ScanLine::iterator _iterPix;
        ScanLine::iterator _iterPixEnd;
        ScanLineContainer::iterator _iterLine;
        ScanLineContainer::iterator _iterLineEnd;
    };
}
