#pragma once

#include <sstream>

#include "Element.h"
#include "Scene.h"


namespace Xml
{
	class Reader
	{
	public:
		inline static std::shared_ptr<tinyxml2::XMLDocument> _doc;

		static Xml::HElement loadXml(std::stringstream& xmlStream)
		{
			Reader::_doc = std::make_shared<tinyxml2::XMLDocument>();
			std::string str = xmlStream.str();
			const char* cstrData = str.c_str();
			_doc->Parse(cstrData);
			tinyxml2::XMLElement* eRoot = Reader::_doc->RootElement();
			std::shared_ptr<Element> hRoot = std::make_shared<Element>(eRoot);
			return hRoot;
		}
	};
}
