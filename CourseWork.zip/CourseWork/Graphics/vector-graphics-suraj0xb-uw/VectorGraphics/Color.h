#pragma once


#include <fstream>
#include <sstream>

#include "Byte.h"

namespace BitmapGraphics
{
	class Color
	{
	public:
		Color(uint8_t r, uint8_t g, uint8_t b) : _red(r), _green(g), _blue(b) { }
		Color() = default;
		~Color() = default;

		Color(const Color&) = default;
		Color(Color&&) = default;
		Color& operator=(const Color&) = default;
		Color& operator=(Color&&) = default;

		uint8_t getRed() { return _red; }
		uint8_t getGreen() { return _green; }
		uint8_t getBlue() { return _blue; }

		static Color read(std::istream& ss);
		void write(std::ostream& ss) const;

		friend std::ostream& operator<<(std::ostream& of, const Color& color);
		friend bool operator==(const Color& lhs, const Color& rhs);
		friend bool operator<(const Color& lhs, const Color& rhs);


	private:
		uint8_t _red;
		uint8_t _green;
		uint8_t _blue;
	};

	std::ostream& operator<<(std::ostream& of, const Color& color);
	bool operator==(const Color& lhs, const Color& rhs);
	bool operator<(const Color& lhs, const Color& rhs);

}

