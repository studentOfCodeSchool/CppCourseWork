#include "WindowsBitmapHeader.h"

#include <iostream>

#include "Byte.h"
#include "Word.h"
#include "DoubleWord.h"


namespace BitmapGraphics
{
	WindowsBitmapHeader::WindowsBitmapHeader()
	{
		FileHeader fh;
		fh.firstIdentifier = 'B';
		fh.secondIdentifier = 'M';
		fh.fileSize = 54;
		fh.reserved = 0;
		fh.rawImageByteOffset = 54;

		InfoHeader ih;
		ih.infoHeaderBytes = 40;
		ih.bitmapWidth = 1;
		ih.bitmapHeight = 1;
		ih.numberOfPlanes = 1;
		ih.bitsPerPixel = 24;
		ih.compressionType = 0;
		ih.horizontalPixelsPerMeter = 0;
		ih.verticalPixelsPerMeter = 0;
		ih.numberOfColors = 0;
		ih.numberOfImportantColors = 0;

		_fileHeader = std::make_shared<FileHeader>(fh);
		_infoHeader = std::make_shared<InfoHeader>(ih);
	}

	WindowsBitmapHeader::WindowsBitmapHeader(int width, int height)
	{
		int bytesInLine = width * 3;
		int remainder = bytesInLine % 4;
		int bytesPadding = (remainder == 0) ? 0 : 4 - remainder;
		bytesInLine += bytesPadding;
		int bytesInImage = height * bytesInLine;
		int fileSize = 54 + bytesInImage;

		FileHeader fh;
		fh.firstIdentifier = 'B';
		fh.secondIdentifier = 'M';
		fh.fileSize = fileSize;
		fh.reserved = 0;
		fh.rawImageByteOffset = 54;

		InfoHeader ih;
		ih.infoHeaderBytes = 40;
		ih.bitmapWidth = width;
		ih.bitmapHeight = height;
		ih.numberOfPlanes = 1;
		ih.bitsPerPixel = 24;
		ih.compressionType = 0;
		ih.horizontalPixelsPerMeter = 2834;
		ih.verticalPixelsPerMeter = 2834;
		ih.numberOfColors = 0;
		ih.numberOfImportantColors = 0;

		_fileHeader = std::make_shared<FileHeader>(fh);
		_infoHeader = std::make_shared<InfoHeader>(ih);
	}

	WindowsBitmapHeader::WindowsBitmapHeader(std::istream& fs)
	{
		readFileHeader(fs);
		readInfoHeader(fs);
	}

	void WindowsBitmapHeader::write(std::ostream& os)
	{
		Binary::Byte firstIdentifier(_fileHeader->firstIdentifier);
		Binary::Byte secondIdentifier(_fileHeader->secondIdentifier);
		Binary::DoubleWord fileSize(_fileHeader->fileSize);
		Binary::DoubleWord reserved(_fileHeader->reserved);
		Binary::DoubleWord rawImageByteOffset(_fileHeader->rawImageByteOffset);

		Binary::DoubleWord infoHeader(_infoHeader->infoHeaderBytes);
		Binary::DoubleWord bitmapWidth(_infoHeader->bitmapWidth);
		Binary::DoubleWord bitmapHeight(_infoHeader->bitmapHeight);
		Binary::Word numberOfPlanes(_infoHeader->numberOfPlanes);
		Binary::Word bitsPerPixel(_infoHeader->bitsPerPixel);
		Binary::DoubleWord compressionType(_infoHeader->compressionType);
		Binary::DoubleWord compressedImageSize(_infoHeader->compressedImageSize);
		Binary::DoubleWord horizontalPixelPerMeter(_infoHeader->horizontalPixelsPerMeter);
		Binary::DoubleWord verticalPixelPerMeter(_infoHeader->verticalPixelsPerMeter);
		Binary::DoubleWord numberOfColors(_infoHeader->numberOfColors);
		Binary::DoubleWord numberOfImportantColors(_infoHeader->numberOfImportantColors);

		os << firstIdentifier << secondIdentifier << fileSize << reserved << rawImageByteOffset;
		os << infoHeader << bitmapWidth << bitmapHeight << numberOfPlanes << bitsPerPixel;
		os << compressionType << compressedImageSize  << horizontalPixelPerMeter << verticalPixelPerMeter;
		os << numberOfColors << numberOfImportantColors;
	}

	void WindowsBitmapHeader::readFileHeader(std::istream& fs)
	{
		FileHeader fh;
		fh.firstIdentifier = Binary::Byte::read(fs);
		fh.secondIdentifier = Binary::Byte::read(fs);
		fh.fileSize = Binary::DoubleWord::readLittleEndian(fs);
		fh.reserved = Binary::DoubleWord::readLittleEndian(fs);
		fh.rawImageByteOffset = Binary::DoubleWord::readLittleEndian(fs);

		_fileHeader = std::make_shared<FileHeader>(fh);
	}

	void WindowsBitmapHeader::readInfoHeader(std::istream& fs)
	{
		InfoHeader ih;
		ih.infoHeaderBytes = Binary::DoubleWord::readLittleEndian(fs);
		ih.bitmapWidth = Binary::DoubleWord::readLittleEndian(fs);
		ih.bitmapHeight = Binary::DoubleWord::readLittleEndian(fs);
		ih.numberOfPlanes = Binary::Word::readLittleEndian(fs);
		ih.bitsPerPixel = Binary::Word::readLittleEndian(fs);
		ih.compressionType = Binary::DoubleWord::readLittleEndian(fs);
		ih.compressedImageSize = Binary::DoubleWord::readLittleEndian(fs);
		ih.horizontalPixelsPerMeter =Binary::DoubleWord::readLittleEndian(fs);
		ih.verticalPixelsPerMeter = Binary::DoubleWord::readLittleEndian(fs);
		ih.numberOfColors = Binary::DoubleWord::readLittleEndian(fs);
		ih.numberOfImportantColors = Binary::DoubleWord::readLittleEndian(fs);

		_infoHeader = std::make_shared<InfoHeader>(ih);
	}
}

