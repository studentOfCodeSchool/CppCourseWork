#pragma once

#include <fstream>
#include <compare>

namespace Binary
{
	class Word
	{
	public:
		Word() = default;
		~Word() = default;

		Word(uint16_t w) : _word(w) { };

		Word(const Word& src) = default;
		Word(Word&& src) = default;

		Word& operator=(const Word& rhs) = default;
		Word& operator=(Word&& rhs) = default;

		std::strong_ordering operator <=>(const Word& rhs) const = default;

		static uint16_t readLittleEndian(std::istream& ss);
		static uint16_t readBigEndian(std::istream& ss);
		static std::ostream& writeLittleEndian(std::ostream& ss, const uint16_t dw);
		static std::ostream& writeBigEndian(std::ostream& ss, const uint16_t dw);

		friend std::ostream& operator <<(std::ostream& os, const Word& w);

	private:
		uint16_t _word = { 0 };
	};

	std::ostream& operator <<(std::ostream& os, const Word& w);
}
