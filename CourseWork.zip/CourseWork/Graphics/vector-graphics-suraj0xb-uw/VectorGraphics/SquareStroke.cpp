#include "SquareStroke.h"

#include <memory>

namespace BitmapGraphics
{
	SquareStroke::SquareStroke() = default;

	SquareStroke::SquareStroke(std::string& tip, int size, Color color) :
		_size(size), _color(color)
	{
	}

	void SquareStroke::setSize(int size)
	{
		_size = size;
	}

	int SquareStroke::getSize() const
	{
		return _size;
	}

	void SquareStroke::setColor(const Color& color)
	{
		_color = color;
	}

	Color SquareStroke::getColor() const
	{
		return _color;
	}

	HPen SquareStroke::createPen(const HCanvas& hCanvas)
	{
		return HPen{ new SquarePen{hCanvas, _size, _color} };
	}
}
