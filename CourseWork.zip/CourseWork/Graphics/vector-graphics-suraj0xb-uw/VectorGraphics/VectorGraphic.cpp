#include "VectorGraphic.h"

#include "Point.h"
#include <algorithm>
#include <stdexcept>
//#include "SquareStroke.h"


namespace VG
{
	void VectorGraphic::addPoint(const Point& p)
	{
		VG::Point pAdd(p);
		myPath.push_back(std::move(pAdd));
	}

	void VectorGraphic::addPoint(Point&& p)
	{
		myPath.push_back(std::move(p));
	}

	void VectorGraphic::removePoint(const Point& p)
	{
		auto it = myPath.begin();
		while (it != myPath.end())
		{
			if (*it == p)
				it = myPath.erase(it);
			else
				++it;
		}
	}

	void VectorGraphic::erasePoint(int index)
	{
		size_t i = index;
		if (i >= 0 && i < myPath.size())
			myPath.erase(myPath.begin() + index);
		else
			throw std::out_of_range("erase point index out of range.");
	}

	void VectorGraphic::openShape()
	{
		myShapeStyle = ShapeStyle::Open;
	}

	void VectorGraphic::closeShape()
	{
		myShapeStyle = ShapeStyle::Closed;
	}

	bool VectorGraphic::isOpen() const
	{
		return (myShapeStyle == ShapeStyle::Open) ? true : false;
	}

	bool VectorGraphic::isClosed() const
	{
		return !isOpen();
	}

	int VectorGraphic::getWidth() const
	{
		if (myPath.size() <= 2)
			return 0;

		int minX = myPath[0].getX();
		int maxX = myPath[0].getX();

		for (auto& p : myPath)
		{
			if (p.getX() < minX)
				minX = p.getX();

			if (p.getX() > maxX)
				maxX = p.getX();
		}

		return std::abs(minX - maxX);
	}

	int VectorGraphic::getHeight() const
	{
		if (myPath.size() <= 2)
			return 0;

		int minY = myPath[0].getY();
		int maxY = myPath[0].getY();

		for (auto& p : myPath)
		{
			if (p.getY() < minY)
				minY = p.getY();

			if (p.getY() > maxY)
				maxY = p.getY();
		}

		return std::abs(minY - maxY);
	}

	size_t VectorGraphic::getPointCount() const
	{
		return myPath.size();
	}

	const Point& VectorGraphic::getPoint(int index) const
	{
		return myPath[index];
	}

	void VectorGraphic::setStroke(std::string tip, int size, BitmapGraphics::Color color)
	{
		std::string t = "";
		BitmapGraphics::HStroke stroke { new BitmapGraphics::SquareStroke{t, size, color} };
		myStroke = std::move(stroke);
	}

	BitmapGraphics::HStroke VectorGraphic::getStroke() const
	{
		std::string s = "";
		int size = myStroke->getSize();
		BitmapGraphics::Color color = myStroke->getColor();
		return BitmapGraphics::HStroke{ new BitmapGraphics::SquareStroke {s, size, color} };
	}

	bool VectorGraphic::operator==(const VectorGraphic& vg) const
	{
		if (myShapeStyle == vg.myShapeStyle)
		{
			return myPath == vg.myPath;
		}

		return false;
	}

	bool VectorGraphic::operator!=(const VectorGraphic& vg) const
	{
		return !(operator==(vg));
	}

	std::ostream& operator<<(std::ostream& os, const VectorGraphic& vg)
	{
		for (auto& p : vg.myPath)
		{
			os << p;
		}

		return os;
	}
}
