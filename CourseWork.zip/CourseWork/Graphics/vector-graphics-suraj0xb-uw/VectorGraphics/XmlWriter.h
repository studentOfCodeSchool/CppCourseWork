#pragma once

#include <sstream>
#include <iostream>

#include "tinyxml2.h"

#include "Element.h"
#include "Scene.h"
#include "SceneReader.h"
#include "SceneWriter.h"

namespace Xml
{
	class Writer
	{
	public:
		static void writeXml(Xml::HElement root, std::ostream& ostream)
		{
			Framework::Scene scene = Framework::SceneReader::readScene(*(root.get()));
			Xml::HElement readRoot = Framework::SceneWriter::writeScene(scene);

			const tinyxml2::XMLElement* tinyRoot = root->getRoot();
			tinyxml2::XMLPrinter printer;

			tinyxml2::XMLDocument doc = tinyRoot->GetDocument();
			doc.Print(&printer);
			ostream << printer.CStr();
		}
	};
}
