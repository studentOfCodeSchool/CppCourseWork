#include "PlacedGraphic.h"

namespace Framework
{
	void PlacedGraphic::setPlacementPoint(const VG::Point& point)
	{
		_placementPoint = point;
	}

	const VG::Point& PlacedGraphic::getPlacementPoint() const
	{
		return _placementPoint;
	}

	void PlacedGraphic::setGraphic(const VG::HVectorGraphic& graphic)
	{
		_hGraphic = graphic;
	}

	const VG::VectorGraphic& PlacedGraphic::getGraphic() const
	{
		return *_hGraphic;
	}

	bool PlacedGraphic::operator==(const PlacedGraphic& rhs) const
	{
		if (_placementPoint == rhs._placementPoint)
		{
			if (*_hGraphic == *rhs._hGraphic)
				return true;
		}

		return false;
	}
}
