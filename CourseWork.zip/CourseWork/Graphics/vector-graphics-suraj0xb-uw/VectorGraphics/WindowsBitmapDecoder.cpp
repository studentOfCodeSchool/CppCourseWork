#include "WindowsBitmapDecoder.h"

namespace BitmapGraphics
{
    WindowsBitmapDecoder::WindowsBitmapDecoder()
    {
        _header = nullptr;
        _body = std::make_shared<Bitmap>(0, 0);
    }

    HBitmapDecoder WindowsBitmapDecoder::clone(std::istream& sourceStream)
    {
        long long length = 0;
        if (sourceStream) {
            sourceStream.seekg(0, sourceStream.end);
            std::streampos endPos = sourceStream.tellg();
            length = (std::streampos)endPos;
            sourceStream.seekg(0, sourceStream.beg);
        }

        if (length >= 54)
        {
            _header = std::make_shared<WindowsBitmapHeader>(sourceStream);
            uint32_t width = _header->getBitmapWidth();
            uint32_t height = _header->getBitmapHeight();
            _body = std::make_shared<Bitmap>(width, height, sourceStream);
        }

        HBitmapDecoder handle = std::make_shared<WindowsBitmapDecoder>(*this);
        return handle;
    }

    HBitmapIterator WindowsBitmapDecoder::createIterator()
    {
        if (_header == nullptr)
            throw std::runtime_error("Invalid stream: header null");
        if (_body == nullptr)
            throw std::runtime_error("Invalid stream: body null");
        if (_body->getWidth() <= 0 || _body->getHeight() <= 0)
            throw std::runtime_error("Invalid bmp widht or height < 0");

        HBitmapIterator iter = std::make_shared<BitmapIterator>(_body);
        return iter;
    }

    bool WindowsBitmapDecoder::isSupported(const std::string& firstChunk) const
    {
        if (firstChunk.size() < 2)
            return false;

        return ((firstChunk[0] == 'B') && (firstChunk[1] == 'M'));
    }
}
