#pragma once


#include <fstream>
#include <compare>

namespace Binary
{
	class DoubleWord
	{
	public:
		DoubleWord() = default;
		~DoubleWord() = default;

		DoubleWord(const uint32_t dw) : _dword(dw) { };

		DoubleWord(const DoubleWord& src) = default;
		DoubleWord(DoubleWord&& src) = default;

		DoubleWord& operator=(const DoubleWord& rhs) = default;
		DoubleWord& operator=(DoubleWord&& rhs) = default;

		std::strong_ordering operator <=>(const DoubleWord& rhs) const = default;

		static uint32_t readLittleEndian(std::istream& ss);
		static uint32_t readBigEndian(std::istream& ss);
		static std::ostream& writeLittleEndian(std::ostream& ss, const uint32_t dw);
		static std::ostream& writeBigEndian(std::ostream& ss, const uint32_t dw);

		friend std::ostream& operator <<(std::ostream& os, const DoubleWord& dw);
	private:
		uint32_t _dword = { 0 };
	};

	std::ostream& operator <<(std::ostream& os, const DoubleWord& dw);
}
