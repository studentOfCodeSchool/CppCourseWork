#include "Interface.h"
#include "Bitmap.h"
#include "BitmapIterator.h"

namespace BitmapGraphics
{
	Bitmap::Bitmap(uint32_t width, uint32_t height) : _width(0), _height(0)
	{
		ScanLineContainer emptyBitmap;
		emptyBitmap.resize(0);
		_imageData = emptyBitmap;
	}

	Bitmap::Bitmap(uint32_t width, uint32_t height, std::istream& bitmapStream) :
		_width(width), _height(height)
	{
		for (uint32_t i = 0; i < _height; ++i)
		{
			std::vector<Color> scanline;

			unsigned char c;
			std::stringstream ss;
			uint8_t bgr[3];

			int cIndex = 0;
			for (uint32_t i = 0; i < _width * 3; ++i)
			{
				c = (unsigned char)Binary::Byte::read(bitmapStream);
				bgr[cIndex] = c;
				if (cIndex == 2)
					scanline.push_back(Color(bgr[2], bgr[1], bgr[0]));
				cIndex = (cIndex + 1) % 3;
			}

			_imageData.push_back(scanline);
		}
	}

	ScanLineContainer::iterator Bitmap::begin()
	{
		return _imageData.begin();
	}

	ScanLineContainer::iterator Bitmap::end()
	{
		return _imageData.end();
	}

	HBitmapIterator Bitmap::createIterator()
	{
		HBitmap hBitmap = std::make_shared<Bitmap>(*this);
		HBitmapIterator hBitmapIter = std::make_shared<BitmapIterator>(hBitmap);
		return hBitmapIter;
	}

	void Bitmap::write(std::ofstream& os)
	{
		for (auto line : _imageData)
		{
			for (auto c : line)
				os << c;
		}
	}
}
