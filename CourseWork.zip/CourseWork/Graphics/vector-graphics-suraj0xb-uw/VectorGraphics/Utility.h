#pragma once

#include <fstream>

class Utility
{
public:
	static uint16_t ReadWord(std::ifstream& ifs);
	static uint32_t ReadDoubleWord(std::ifstream& ifs);
};

