#pragma once


#include <compare>
#include <memory>
#include <fstream>

namespace Binary
{
	class Byte
	{
	public:
		Byte() = default;
		~Byte() = default;

		Byte(unsigned char b) : _byte(b) { };
		Byte(int b) { _byte = (unsigned char)b; };
		Byte(char b) : _byte(b) { };

		Byte(const Byte& src) = default;
		Byte(Byte&& src) = default;

		Byte& operator= (const Byte& rhs) = default;
		Byte& operator= (Byte&& rhs) = default;

		operator unsigned char() const;

		static Byte read(std::istream& is);
		void write(std::ostream& ss);

		friend std::ostream& operator <<(std::ostream& os, const Byte& b);
		friend bool operator ==(const Byte& b, const unsigned char& c);
		friend bool operator ==(const unsigned char& c, const Byte& b);
		friend bool operator ==(const char& c, const Byte& b);

	private:
		uint8_t _byte = { 0 };
	};

	std::ostream& operator <<(std::ostream& os, const Byte& b);
	bool operator ==(const Byte& b, const unsigned char& c);
	bool operator ==(const unsigned char& c, const Byte& b);
	bool operator ==(const char& c, const Byte& b);
}
