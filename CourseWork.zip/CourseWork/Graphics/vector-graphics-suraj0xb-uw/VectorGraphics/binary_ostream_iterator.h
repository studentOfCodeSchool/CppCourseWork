#pragma once

#include "Bitmap.h"

namespace BitmapGraphics
{
#ifndef SC
#define SC
	typedef std::vector<Color> ScanLine;
	typedef std::vector<ScanLine> ScanLineContainer;
#endif

	template <class T,
		class _Category = std::output_iterator_tag,
		class _Diff = ptrdiff_t,
		class _Pointer = T*,
		class _Reference = T& >
	class binary_ostream_iterator
	{
	private:
		//Color _data;
		std::ostream* _myOutputStream;
	public:
		using _Unchecked_type = binary_ostream_iterator;

		using iterator_category = _Category;
		using value_type = T;
		using difference_type = _Diff;
		using pointer = _Pointer;
		using reference = _Reference;

		binary_ostream_iterator() = delete;
		~binary_ostream_iterator() = default;

		explicit binary_ostream_iterator(std::ostream& os) : _myOutputStream(&os)
		{
		};

		binary_ostream_iterator(const binary_ostream_iterator&) = default;
		binary_ostream_iterator(binary_ostream_iterator&&) = default;
		binary_ostream_iterator& operator=(const binary_ostream_iterator&) = default;
		binary_ostream_iterator& operator=(binary_ostream_iterator&&) = default;


		// assignment operator writes a value to the output stream
		binary_ostream_iterator& operator=(const T& value)
		{
			value.write(*_myOutputStream);
			return *this;
		}

		// dereferencing is a no-op that returns the iterator itself
		binary_ostream_iterator& operator*() noexcept
		{
			return *this;
		}

		// increment is a no-op that returns the iterator itself
		binary_ostream_iterator<T>& operator++() noexcept
		{
			return *this;
		}

		binary_ostream_iterator<T>& operator++(int) noexcept
		{
			return *this;
		}
	};
}
