#pragma once

#include <memory>

#include "Point.h"
#include "ICanvas.h"
#include "BasicCanvas.h"

namespace BitmapGraphics
{
	class IPen;
	using HPen = std::shared_ptr<IPen>;

	class IPen
	{
	public:
		IPen() = default;

		IPen(const IPen&) = delete;
		IPen(IPen&&) = delete;
		IPen& operator=(const IPen&) = delete;
		IPen& operator=(IPen&&) = delete;

		virtual ~IPen() = default;
		virtual void drawPoint(const VG::Point& point) = 0;
	};
}
