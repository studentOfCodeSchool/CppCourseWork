#pragma once

#include <string>
#include <fstream>
#include <memory>

#include "Interface.h"
#include "Bitmap.h"
#include "BitmapIterator.h"
#include "WindowsBitmapHeader.h"


namespace BitmapGraphics
{
    class WindowsBitmapDecoder : public IBitmapDecoder
    {
    public:
        WindowsBitmapDecoder();
        virtual ~WindowsBitmapDecoder() =default;

        WindowsBitmapDecoder(const WindowsBitmapDecoder& ) =default;
        WindowsBitmapDecoder(WindowsBitmapDecoder&& ) =default;
        WindowsBitmapDecoder& operator=(const WindowsBitmapDecoder& ) =default;
        WindowsBitmapDecoder& operator=(WindowsBitmapDecoder&& ) =default;


        HBitmapDecoder clone(std::istream& fs) override;
        HBitmapIterator createIterator() override;
        const std::string& getMimeType() const override { return _mimeType; }
        bool isSupported(const std::string&) const override;

    private:
        std::string _mimeType = "image/x-ms-bmp";
        HWindowsBitmapHeader _header;
        HBitmap _body;
    };
}
