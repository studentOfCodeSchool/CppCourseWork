#include "BasicCanvas.h"

namespace BitmapGraphics
{
    BasicCanvas::BasicCanvas() = default;
   
    BasicCanvas::BasicCanvas(int width, int height) :
        _width(width), _height(height), _backgroundColor(255, 255, 255)
    {
    }

    BasicCanvas::BasicCanvas(int width, int height, Color c) :
        _width(width), _height(height), _backgroundColor(c)
    {
    }

    Color BasicCanvas::getPixelColor(const VG::Point pt) const
    {
        if ((pt.getX() < 0) || (pt.getX() >= _width) ||
            (pt.getY() < 0) || (pt.getY() >= _height))
            throw std::out_of_range("pt is outside the canvas");

        auto itr = _canvasPixels.find(pt);
        if (itr != _canvasPixels.end())
            return itr->second;

        return _backgroundColor;
    }

    void BasicCanvas::setPixelColor(const VG::Point pt, const Color color)
    {
        if ((pt.getX() < 0) || (pt.getX() >= _width) ||
            (pt.getY() < 0) || (pt.getY() >= _height))
            throw std::out_of_range("pt is outside the canvas");

        _canvasPixels[pt] = color;
    }

    HBitmapIterator BasicCanvas::createBitmapIterator() const
    {
        std::stringstream bitmapStream;
        for (int i = 0; i < (int)_width; ++i)
            for (int j = 0; j < (int)_height; ++j)
            {
                VG::Point pt(i, j);
                Color color = _backgroundColor;
                auto iter = _canvasPixels.find(pt);
                if (iter != end(_canvasPixels))
                    color = iter->second;
                color.write(bitmapStream);
            }

        bitmapStream.seekg(0);

        HBitmap hBitmap = std::make_shared<Bitmap>(_width, _height, bitmapStream);
        return hBitmap->createIterator();
    }
}
