#pragma once

#include <memory>
#include <fstream>
#include "Bitmap.h"

namespace BitmapGraphics
{

#ifndef SC2 
#define SC2
    class BitmapIterator;
    class IBitmapIterator;
    //typedef std::shared_ptr<BitmapIterator> HBitmapIterator;
    using HBitmapIterator = std::shared_ptr<IBitmapIterator>;
#endif

    class WindowsBitmapDecoder;
    typedef std::shared_ptr<WindowsBitmapDecoder> HBitmapDecoder;

    class IBitmapDecoder
    {
    public:
        IBitmapDecoder() = default;
        virtual ~IBitmapDecoder() = default;

        virtual HBitmapDecoder clone(std::istream& sourceStream) = 0;
        virtual HBitmapIterator createIterator() = 0;
        virtual const std::string& getMimeType() const = 0;
        virtual bool isSupported(const std::string&) const= 0;
    };

    class WindowsBitmapEncoder;
    typedef std::shared_ptr<WindowsBitmapEncoder> HBitmapEncoder;

    class IBitmapEncoder
    {
    public:
        IBitmapEncoder() = default;
        virtual ~IBitmapEncoder() = default;

        virtual HBitmapEncoder clone(HBitmapIterator ) =0;
        virtual void encodeToStream(std::ostream& destinationStream) = 0;
        virtual const std::string& getMimeType() const = 0;
    };

    class IBitmapIterator
    {
    public:
        virtual ScanLine& nextScanLine() =0;
        virtual bool isEndOfImage() =0;
        virtual void nextPixel() =0;
        virtual bool isEndOfScanLine() =0;
        virtual Color getColor() =0;
        virtual uint32_t getBitmapWidth() =0;
        virtual uint32_t getBitmapHeight() =0;
    };


    const std::string MimeType = "image/x-ms-bmp";

    class NumberPaddingBytes
    {
    public:
        NumberPaddingBytes(int n) : num(n) { };
        ~NumberPaddingBytes() = default;

        int getNumberOfBytesToPad()
        {
            int remainder = num % 4;
            int bytesToPad = (remainder == 0) ? 0 : 4 - remainder;
            return bytesToPad;
        }
    private:
        int num;
    };
}
