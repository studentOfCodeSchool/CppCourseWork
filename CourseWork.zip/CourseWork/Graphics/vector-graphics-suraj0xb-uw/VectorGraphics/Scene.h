#pragma once

#include <list>

#include "Layer.h"
#include "BasicCanvas.h"

namespace Framework
{
	using Layers = std::list<Layer>;
	using LayerIterator = std::list<Layer>::iterator;

	class Scene
	{
	public:
		Scene(int width, int height) : _width(width), _height(height) { }
		~Scene() = default;

		Scene(const Scene& src) = default;
		Scene(Scene&& src) = default;
		Scene& operator=(const Scene& rhs) = default;
		Scene& operator=(Scene&& rhs) = default;

		void pushBack(const Layer& layer);
		void remove(const Layer& layer);

		int getWidth() const { return _width; }
		int getHeight() const { return _height; }

		void draw(BitmapGraphics::HCanvas canvas);

		LayerIterator begin();
		LayerIterator end();
		LayerIterator& operator++();
		LayerIterator operator++(int);

	private:
		int _width = 0;
		int _height = 0;
		Layers _layers;
		LayerIterator _iter;
	};
}