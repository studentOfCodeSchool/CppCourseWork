#pragma once

#include "XmlReader.h"


namespace Framework
{
	class SceneReader
	{
	public:
		static Scene readScene(Xml::Element& node);

	private:
		static int convertToInt(const std::string& value);
		static BitmapGraphics::Color convertToColor(const std::string& value);
	};
}
