#include "DoubleWord.h"

namespace Binary
{
	uint32_t DoubleWord::readLittleEndian(std::istream& ss)
	{
		uint32_t dw = 0;
		uint8_t c1, c2, c3, c4;

		c1 = ss.get();
		c2 = ss.get();
		c3 = ss.get();
		c4 = ss.get();
		//ss >> c1 >> c2 >> c3 >> c4;
		dw |= (0x00FF & c4);
		dw = dw << 8;
		dw |= (0x00FF & c3);
		dw = dw << 8;
		dw |= (0x00FF & c2);
		dw = dw << 8;
		dw |= (0x00FF & c1);
		return dw;
	}

	uint32_t DoubleWord::readBigEndian(std::istream& ss)
	{
		uint32_t dw = 0;
		uint8_t c1, c2, c3, c4;
		c1 = ss.get();
		c2 = ss.get();
		c3 = ss.get();
		c4 = ss.get();
		//ss >> c1 >> c2 >> c3 >> c4;
		dw |= (0x00FF & c1);
		dw = dw << 8;
		dw |= (0x00FF & c2);
		dw = dw << 8;
		dw |= (0x00FF & c3);
		dw = dw << 8;
		dw |= (0x00FF & c4);
		return dw;
	}

	std::ostream& DoubleWord::writeLittleEndian(std::ostream& ss, const uint32_t dw)
	{
		uint8_t c1, c2, c3, c4;
		uint32_t d1, d2, d3, d4;
		d1 = d2 = d3 = d4 = dw;
		d1 = (0x000000FF & d1);
		d2 = (0x0000FF00 & d2) >> 8;
		d3 = (0x00FF0000 & d3) >> 16;
		d4 = (0xFF000000 & d4) >> 24;

		c1 = 0x000000FF & d1;
		c2 = 0x000000FF & d2;
		c3 = 0x000000FF & d3;
		c4 = 0x000000FF & d4;

		//ss << c1 << c2 << c3 << c4;
		ss.put(c1);
		ss.put(c2);
		ss.put(c3);
		ss.put(c4);

		return ss;
	}

	std::ostream& DoubleWord::writeBigEndian(std::ostream& ss, const uint32_t dw)
	{
		uint8_t c1, c2, c3, c4;
		uint32_t d1, d2, d3, d4;
		d1 = d2 = d3 = d4 = dw;
		d1 = (0x000000FF & d1);
		d2 = (0x0000FF00 & d2) >> 8;
		d3 = (0x00FF0000 & d3) >> 16;
		d4 = (0xFF000000 & d4) >> 24;

		c1 = 0x000000FF & d1;
		c2 = 0x000000FF & d2;
		c3 = 0x000000FF & d3;
		c4 = 0x000000FF & d4;

		// ss << c4 << c3 << c2 << c1;
		ss.put(c4);
		ss.put(c3);
		ss.put(c2);
		ss.put(c1);

		return ss;
	}

	std::ostream& operator <<(std::ostream& os, const DoubleWord& doubleWord)
	{
		DoubleWord::writeLittleEndian(os, doubleWord._dword);
		return os;
	}
}
