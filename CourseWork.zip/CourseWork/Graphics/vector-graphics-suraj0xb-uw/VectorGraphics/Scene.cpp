#include "Scene.h"
#include "Layer.h"
#include "LineIterator.h"
#include "Color.h"

#include <algorithm>

namespace Framework
{
	void Scene::pushBack(const Framework::Layer& layer)
	{
		_layers.push_back(layer);
	}

	void Scene::remove(const Framework::Layer& layer)
	{
		_layers.remove(layer);
	}

	LayerIterator Scene::begin()
	{
		_iter = _layers.begin();
		return _layers.begin();
	}

	LayerIterator Scene::end()
	{
		return _layers.end();
	}

	LayerIterator& Scene::operator ++()
	{
		return ++_iter;
	}

	LayerIterator Scene::operator ++(int)
	{
		LayerIterator iterPreIncr = _iter;
		++_iter;
		return iterPreIncr;
	}

	void Scene::draw(BitmapGraphics::HCanvas hCanvas)
	{
		for (auto iterLayer = begin();
			iterLayer != end();
			++iterLayer)
		{
			Layer layer = (*iterLayer);
			for (auto iterGraphic = layer.begin();
				iterGraphic != layer.end();
				++iterGraphic)
			{
				PlacedGraphic graphic = *iterGraphic;
				VG::Point ptPlacement = graphic.getPlacementPoint();

				const VG::VectorGraphic& vg = graphic.getGraphic();
				bool isClosed = vg.isClosed();
				BitmapGraphics::Color color(0, 0, 0);
				VG::Point ptStart(0, 0);
				VG::Point ptEnd(0, 0);
				BitmapGraphics::HPen hPen = vg.getStroke()->createPen(hCanvas);
				for (size_t i = 1; i <= vg.getPointCount(); ++i)
				{
					if (i < vg.getPointCount())
					{
						ptStart = vg.getPoint((int)i - 1);
						ptEnd = vg.getPoint((int)i);
					}
					else
					{
						if (vg.isClosed())
						{
							ptStart = vg.getPoint((int)i - 1);
							ptEnd = vg.getPoint(0);
						}
						else
							continue;
					}

					ptStart = ptStart + ptPlacement;
					ptEnd = ptEnd + ptPlacement;

					LineIterator line(ptStart, ptEnd);
					line.getBeginPoint();
					while (!line.isEnd())
					{
						VG::Point pt = line.getCurrentPoint();
						hPen->drawPoint(pt);
						line.nextPoint();
					}
					hPen->drawPoint(ptEnd);
				}
			}
		}
	}
}
