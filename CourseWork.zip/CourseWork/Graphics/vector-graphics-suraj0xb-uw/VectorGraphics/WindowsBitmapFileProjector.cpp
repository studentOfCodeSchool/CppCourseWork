#include "WindowsBitmapFileProjector.h"
#include "BitmapIterator.h"

namespace BitmapGraphics
{
    WindowsBitmapFileProjector::WindowsBitmapFileProjector(std::string filename, CodecLibrary& codecLib) :
        _filename(filename), _codecLib(codecLib)
    {
    }

    void WindowsBitmapFileProjector::projectCanvas(const HCanvas hCanvas) 
    {
        std::ofstream outputStream(_filename.c_str(), std::ios::binary);
        HBitmapIterator bitmapIter = hCanvas->createBitmapIterator();
        HBitmapEncoder encoder = _codecLib.createEncoder("image/x-ms-bmp", bitmapIter);
        encoder->encodeToStream(outputStream);
        outputStream.close();
    }
}


