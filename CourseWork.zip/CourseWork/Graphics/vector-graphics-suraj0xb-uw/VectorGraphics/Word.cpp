#include "Word.h"

#include <sstream>
#include <iostream>

namespace Binary
{
	uint16_t Word::readLittleEndian(std::istream& ss)
	{
		uint16_t w = 0;
		uint8_t c1, c2;
		// ss >> c1 >> c2;
		c1 = ss.get();
		c2 = ss.get();
		w = 0x00FF & c2;
		w = w << 8;
		w |= 0x00FF & c1;
		return w;
	}

	uint16_t Word::readBigEndian(std::istream& ss)
	{
		uint16_t w = 0;
		uint8_t c1, c2;
		//ss >> c1 >> c2;
		c1 = ss.get();
		c2 = ss.get();
		w = 0x00FF & c1;
		w = w << 8;
		w |= 0x00FF & c2;
		return w;
	}

	std::ostream& Word::writeLittleEndian(std::ostream& ss, const uint16_t dw)
	{
		uint8_t c1, c2;
		uint16_t d1, d2;
		d1 = d2 = dw;
		d1 = (0x00FF & d1);
		d2 = (0xFF00 & d2) >> 8;

		c1 = (unsigned char)(0x000FF & d1);
		c2 = (unsigned char)(0x00FF & d2);

		//ss << c1 << c2;
		ss.put(c1);
		ss.put(c2);
		return ss;
	}

	std::ostream& Word::writeBigEndian(std::ostream& ss, const uint16_t dw)
	{
		uint8_t c1, c2;
		uint16_t d1, d2;
		d1 = d2 = dw;
		d1 = (0x00FF & d1);
		d2 = (0xFF00 & d2) >> 8;

		c1 = (unsigned char)(0x00FF & d1);
		c2 = (unsigned char)(0x00FF & d2);

		//ss << c2 << c1;
		ss.put(c2);
		ss.put(c1);

		return ss;
	}

	std::ostream& operator <<(std::ostream& os, const Word& w)
	{
		Word::writeLittleEndian(os, w._word);
		return os;
	}
}
