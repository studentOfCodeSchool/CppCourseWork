#pragma once

#include <fstream>
#include <string>


#include "IProjector.h"
#include "CodecLibrary.h"

namespace BitmapGraphics
{
    class WindowsBitmapFileProjector : IProjector
    {
    public:
        WindowsBitmapFileProjector(std::string filename, CodecLibrary& codecLib);

        void projectCanvas(const HCanvas canvas) override;

    private:
        std::string _filename;
        CodecLibrary _codecLib;
    };

    using HProjector = std::shared_ptr<WindowsBitmapFileProjector>;
}
