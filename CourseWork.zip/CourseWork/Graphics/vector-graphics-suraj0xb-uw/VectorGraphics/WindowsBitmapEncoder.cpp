#include "WindowsBitmapEncoder.h"

#include "Byte.h"
#include "Word.h"
#include "DoubleWord.h"
#include "Interface.h"

namespace BitmapGraphics 
{
    HBitmapEncoder WindowsBitmapEncoder::clone(HBitmapIterator bitmapIterator)
    {
        _bitmapIter = bitmapIterator;
        HBitmapEncoder handle = std::make_shared<WindowsBitmapEncoder>(*this);
        return handle;
    }

    void WindowsBitmapEncoder::encodeToStream(std::ostream& destinationStream)
    {
        if (_bitmapIter == nullptr)
            throw std::runtime_error("invalid encoder");

        uint32_t width = _bitmapIter->getBitmapWidth();
        uint32_t height = _bitmapIter->getBitmapHeight();

        WindowsBitmapHeader header(width, height);
        header.write(destinationStream);
        
        int numberOfScanLines = 0;
        int numberOfPixelsInScanLine = 0;
        int count = 0;
        while (!_bitmapIter->isEndOfImage())
        {
            numberOfPixelsInScanLine = 0;
            while (!_bitmapIter->isEndOfScanLine())
            {
                count++;
                Color c = _bitmapIter->getColor();
                c.write(destinationStream);
                ++numberOfPixelsInScanLine;
                _bitmapIter->nextPixel();
            }
            ++numberOfScanLines;

            writePadBytes(destinationStream);
            _bitmapIter->nextScanLine();
        }
        destinationStream.flush();
    }

    void WindowsBitmapEncoder::writePadBytes(std::ostream& destinationStream) const
    {
        NumberPaddingBytes calc(_bitmapIter->getBitmapWidth() * 3);
        int bytesToPad = calc.getNumberOfBytesToPad();
        for (int i = 0; i < bytesToPad; ++i)
        {
            Binary::Byte b(0);
            b.write(destinationStream);
        }
    }
}
