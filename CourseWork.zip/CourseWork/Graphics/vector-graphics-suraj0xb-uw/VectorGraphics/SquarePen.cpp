#include "SquarePen.h"

namespace BitmapGraphics
{
	SquarePen::SquarePen() = default;

	SquarePen::SquarePen(HCanvas hCanvas, int width, Color color) :
		_hCanvas(hCanvas), _width(width), _color(color)
	{
	}

	void SquarePen::drawPoint(const VG::Point& point)
	{
		int offset = _width / 2;
		int xStart = point.getX() - offset;
		int xEnd = point.getX() + offset;
		int yStart = point.getY() - offset;
		int yEnd = point.getY() + offset;

		for (int x = xStart; x <= xEnd; ++x)
		{
			for (int y = yStart; y <= yEnd; ++y)
			{
				VG::Point pt(x, y);
				_hCanvas->setPixelColor(pt, _color);
			}
		}
	}
}
