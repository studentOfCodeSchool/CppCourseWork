#pragma once

#include "tinyxml2.h"

#include <map>
#include <vector>
#include <string>
#include <memory>


namespace Xml
{
	class Element;

	typedef std::shared_ptr<Element> HElement;

	using AttributeMap = std::map<std::string, std::string>;
	using ElementList = std::vector<std::shared_ptr<Element> >;



	class Element
	{
	public:
		Element(const tinyxml2::XMLElement* element) : _xmlElement(element) { }
		~Element() { }

		Element(const Element& src) = default;
		Element(Element&& src) = delete;

		Element& operator=(const Element& rhs) = default;
		Element& operator=(Element&& rhs) = delete;

		HElement operator [](int index) const;

		std::string getName() const;
		AttributeMap getAttributes() const;
		ElementList getChildElements() const;

		std::string getAttribute(const std::string str);

		const tinyxml2::XMLElement* getRoot() { return _xmlElement; }


	private:
		const tinyxml2::XMLElement* _xmlElement;
	};
}
