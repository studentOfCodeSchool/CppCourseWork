#pragma once

#include <memory>

#include "Point.h"
#include "VectorGraphic.h"


namespace VG
{
	using HVectorGraphic = std::shared_ptr<VectorGraphic>;
}

namespace Framework
{
	class PlacedGraphic
	{
	public:
		PlacedGraphic() = default;
		PlacedGraphic(VG::Point point, VG::HVectorGraphic vg) : _placementPoint(point), _hGraphic(vg) { }
		~PlacedGraphic() = default;


		PlacedGraphic(const PlacedGraphic& src) = default;
		PlacedGraphic(PlacedGraphic&& src) = default;

		PlacedGraphic& operator=(const PlacedGraphic& rhs) = default;
		PlacedGraphic& operator=(PlacedGraphic&& rhs) = default;

		void setPlacementPoint(const VG::Point& placement);
		const VG::Point& getPlacementPoint() const;

		void setGraphic(const VG::HVectorGraphic& graphic);
		const VG::VectorGraphic& getGraphic() const;

		bool operator==(const PlacedGraphic& rhs) const;

	private:
		VG::Point _placementPoint = { 0, 0 };
		VG::HVectorGraphic _hGraphic;
	};
}
