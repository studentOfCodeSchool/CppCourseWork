#include "SceneWriter.h"

#include <stdexcept>
#include <sstream>
#include <memory>

namespace Framework
{
	std::shared_ptr<tinyxml2::XMLDocument> SceneWriter::_doc;

	Xml::HElement SceneWriter::writeScene(Scene& scene)
	{
		_doc = std::make_shared<tinyxml2::XMLDocument>();
		tinyxml2::XMLElement* xmlElementScene = _doc->NewElement("Scene");
		xmlElementScene->SetAttribute("width", scene.getWidth());
		xmlElementScene->SetAttribute("height", scene.getHeight());

		for (auto iterLayer = scene.begin();
			iterLayer != scene.end();
			++iterLayer)
		{
			Layer layer = (*iterLayer);
			tinyxml2::XMLElement* xmlElementLayer = _doc->NewElement("Layer");
			xmlElementLayer->SetAttribute("alias", layer.getAlias().c_str());
			xmlElementScene->InsertEndChild(xmlElementLayer);

			for (auto iterGraphic = layer.begin();
				iterGraphic != layer.end();
				++iterGraphic)
			{
				PlacedGraphic graphic = (*iterGraphic);
				tinyxml2::XMLElement* xmlElementGraphic = _doc->NewElement("PlacedGraphic");
				xmlElementGraphic->SetAttribute("x", graphic.getPlacementPoint().getX());
				xmlElementGraphic->SetAttribute("y", graphic.getPlacementPoint().getY());
				xmlElementLayer->InsertEndChild(xmlElementGraphic);

				const VG::VectorGraphic& vg = graphic.getGraphic();
				tinyxml2::XMLElement* xmlElementVG = _doc->NewElement("VectorGraphic");
				xmlElementVG->SetAttribute("closed", (vg.isClosed()) ? "true" : "false");
				xmlElementGraphic->InsertEndChild(xmlElementVG);

				for (size_t i = 0; i < vg.getPointCount(); ++i)
				{
					VG::Point point = vg.getPoint((int)i);
					tinyxml2::XMLElement* xmlElementPoint = _doc->NewElement("Point");
					xmlElementPoint->SetAttribute("x", point.getX());
					xmlElementPoint->SetAttribute("y", point.getY());
					xmlElementVG->InsertEndChild(xmlElementPoint);
				}
			}
		}

		_doc->InsertFirstChild(xmlElementScene);

		tinyxml2::XMLElement* root = _doc->RootElement();
		std::shared_ptr<Xml::Element> rootElement = std::make_shared<Xml::Element>(root);
		return rootElement;
	}
}
