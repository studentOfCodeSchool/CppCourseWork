#pragma once

#include "IPen.h"
#include "Color.h"
#include "ICanvas.h"
#include "BasicCanvas.h"
#include "IPen.h"
#include <memory>

namespace BitmapGraphics
{
	class SquarePen final : public IPen
	{
	public:
		SquarePen();
		explicit SquarePen(HCanvas, int, Color);
			 
		void drawPoint(const VG::Point& point) override;
	
	private:
		HCanvas _hCanvas;
		int _width;
		Color _color;
	};
}
