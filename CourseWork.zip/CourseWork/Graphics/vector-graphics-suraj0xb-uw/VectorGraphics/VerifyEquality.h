#pragma once

#include <string>
#include <exception>

#include "Word.h"

namespace Binary
{
	bool verifyEquality(Binary::Word lhs, Binary::Word rhs, std::string str)
	{
		if (lhs == rhs)
			return true;
		throw std::runtime_error(str);
	}
}

