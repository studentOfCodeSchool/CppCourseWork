#pragma once

#include <fstream>
#include <memory>

#include "WindowsBitmapHeader.h"
#include "Color.h"
#include "binary_ostream_iterator.h"

#include "Byte.h"
#include "Word.h"
#include "DoubleWord.h"

namespace BitmapGraphics
{
	class Bitmap;
#ifndef SC
#define SC
	typedef std::vector<Color> ScanLine;
	typedef std::vector<ScanLine> ScanLineContainer;
#endif

#ifndef SC2
#define SC2
	class IBitmapIterator;
	using HBitmapIterator = std::shared_ptr<IBitmapIterator>;
#endif

	class Bitmap
	{
	public:
		Bitmap(uint32_t width, uint32_t height);
		Bitmap(uint32_t width, uint32_t height, std::istream& bitmapStream);
		~Bitmap() = default;

		Bitmap(const Bitmap&) = default;
		Bitmap(Bitmap&&) = default;
		Bitmap& operator=(const Bitmap&) = default;
		Bitmap& operator=(Bitmap&&) = default;

		uint32_t getWidth() { return _width; }
		uint32_t getHeight() { return _height; }
		int getNumberOfPadBytes() { return (int)0; }

		void write(std::ofstream&);

		ScanLineContainer::iterator begin();
		ScanLineContainer::iterator end();
		HBitmapIterator createIterator();

	private:
		uint32_t _width;
		uint32_t _height;
		ScanLineContainer _imageData = { };
	};

	typedef std::shared_ptr<Bitmap> HBitmap;
}
