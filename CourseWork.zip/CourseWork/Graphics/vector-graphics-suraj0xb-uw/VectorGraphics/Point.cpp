#include "Point.h"
#include <iostream>

namespace VG
{
	std::ostream& operator<<(std::ostream& os, const Point& p)
	{
		// ADD IMPLEMENTATION HERE!
		os << "(" << p.getX() << "," << p.getY() << ")" << std::endl;
		return os;
	}

	bool Point::operator==(const Point& rhs) const
	{
		if (this->myX == rhs.myX &&
			this->myY == rhs.myY)
			return true;

		return false;
	}

	bool Point::operator!=(const Point& rhs) const
	{
		if (operator==(rhs))
			return false;
		return true;
	}

	Point Point::operator+(const Point& rhs)
	{
		Point p(0, 0);
		p.myX = this->myX + rhs.myX;
		p.myY = this->myY + rhs.myY;
		return p;
	}

	Point Point::operator-(const Point& rhs)
	{
		Point p(0, 0);
		p.myX = this->myX - rhs.myX;
		p.myY = this->myY - rhs.myY;
		return p;
	}

	bool Point::operator<(const Point& rhs) const
	{
		if (this->myX < rhs.myX)
			return true;

		if (this->myX == rhs.myX)
		{
			if (this->myY < rhs.myY)
				return true;
		}

		return false;
	}
}
