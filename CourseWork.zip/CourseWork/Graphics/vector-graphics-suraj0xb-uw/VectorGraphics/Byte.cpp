#include "Byte.h"

namespace Binary
{
	Byte Byte::read(std::istream& sstream)
	{
		int c = sstream.get();
		Byte b(static_cast<unsigned char>(c));
		return b;
	}

	void Byte::write(std::ostream& ss)
	{
		const unsigned char c = _byte;
		ss.put(c);
	}

	Byte::operator unsigned char() const
	{
		return _byte;
	}

	std::ostream& operator <<(std::ostream& os, const Byte& b)
	{
		Byte bc(b);
		bc.write(os);
		return os;
	}


	bool operator ==(const Byte& b, const unsigned char& c)
	{
		if (b._byte == c)
			return true;

		return false;
	}

	bool operator ==(const unsigned char& c, const Byte& b)
	{
		if (c == b._byte)
			return true;

		return false;
	}

	bool operator ==(const char& c, const Byte& b)
	{
		if (c == b._byte)
			return true;

		return false;
	}
}
