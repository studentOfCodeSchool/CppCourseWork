#pragma once

#include "Interface.h"
#include "BitmapIterator.h"

#include <memory>

namespace BitmapGraphics
{
    class BitmapIteratorDecorator : public IBitmapIterator
    {
    public:
        BitmapIteratorDecorator(HBitmapIterator );
        virtual ~BitmapIteratorDecorator() =default;

        BitmapIteratorDecorator(const BitmapIteratorDecorator& ) =default;
        BitmapIteratorDecorator(BitmapIteratorDecorator&& ) =default;
        BitmapIteratorDecorator& operator=(const BitmapIteratorDecorator& ) =default;
        BitmapIteratorDecorator& operator=(BitmapIteratorDecorator&& ) =default;

        
        ScanLine& nextScanLine() override;
        bool isEndOfImage() override;
        void nextPixel() override;
        bool isEndOfScanLine() override;
        Color getColor() override;
        uint32_t getBitmapWidth() override;
        uint32_t getBitmapHeight() override;


    protected:
        HBitmapIterator _hBitmapIterator;
    };

    typedef std::shared_ptr<BitmapIteratorDecorator> HBitmapIteratorDecorator;
}
