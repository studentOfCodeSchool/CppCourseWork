#include "Color.h"

namespace BitmapGraphics
{
	Color Color::read(std::istream& ss)
	{
		Color c;
		c._blue = Binary::Byte::read(ss);
		c._green = Binary::Byte::read(ss);
		c._red = Binary::Byte::read(ss);
		return c;
	}

	void Color::write(std::ostream& ss) const
	{
		Binary::Byte b = (unsigned char) _blue;
		Binary::Byte g = (unsigned char) _green;
		Binary::Byte r = (unsigned char) _red;

		b.write(ss);
		g.write(ss);
		r.write(ss);
	}

	std::ostream& operator<<(std::ostream& of, const Color& color)
	{
		of << color._blue << color._green << color._red;
		return of;
	}
	
	bool operator==(const Color& lhs, const Color& rhs)
	{
		if ((lhs._red == rhs._red) && (lhs._green == rhs._green) && (lhs._blue == rhs._blue))
			return true;
		return false;
	}

	bool operator<(const Color& lhs, const Color& rhs)
	{
		if (lhs == rhs)
			return false;
		if (lhs._red >= rhs._red)
			return false;
		if (lhs._green >= rhs._green)
			return false;
		if (lhs._blue >= rhs._blue)
			return false;
		return true;
	}
}
