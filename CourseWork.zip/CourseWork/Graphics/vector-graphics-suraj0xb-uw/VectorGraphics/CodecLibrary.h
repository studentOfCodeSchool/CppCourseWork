#pragma once

#include <sstream>
#include <vector>
#include <exception>

#include "Interface.h"
#include "Bitmap.h"
#include "BitmapIterator.h"
#include "WindowsBitmapEncoder.h"
#include "WindowsBitmapDecoder.h"


namespace BitmapGraphics
{
    class CodecLibrary
    {
    public:
        CodecLibrary() =default;
        ~CodecLibrary() =default;

        CodecLibrary(const CodecLibrary& ) =default;
        CodecLibrary(CodecLibrary&& ) =default;
        CodecLibrary& operator=(const CodecLibrary& ) =default;
        CodecLibrary& operator=(CodecLibrary&& ) =default;

        void registerEncoder(HBitmapEncoder hbitmapEncoder);
        void registerDecoder(HBitmapDecoder hBitmapDecoder);

        HBitmapEncoder createEncoder(const std::string& mimeType, HBitmapIterator iter);
        HBitmapDecoder createDecoder(const std::string& mimeType, std::istream& ss);
        HBitmapDecoder createDecoder(std::istream& fs);
        
    private:
        std::vector<HBitmapEncoder> _encoders;
        std::vector<HBitmapDecoder> _decoders;
    };
}
