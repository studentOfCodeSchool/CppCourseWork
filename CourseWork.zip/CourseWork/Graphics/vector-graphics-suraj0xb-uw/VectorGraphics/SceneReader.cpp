#include "SceneReader.h"

#include <exception>
#include <sstream>
#include <memory>

#include "Layer.h"
#include "PlacedGraphic.h"
#include "Color.h"

namespace Framework
{
	Scene SceneReader::readScene(Xml::Element& node)
	{
		std::string value = node.getAttribute("width");
		int width = convertToInt(node.getAttribute("width"));
		int height = convertToInt(node.getAttribute("height"));

		Scene scene(width, height);

		Xml::ElementList listLayer = node.getChildElements();
		auto iterLayer = listLayer.begin();

		while (iterLayer != listLayer.end())
		{
			Xml::HElement hElementLayer = *(iterLayer);
			std::string alias = hElementLayer->getAttribute("alias");

			Layer layer(alias);

			Xml::ElementList listPlacedGraphics = hElementLayer->getChildElements();
			auto iterPlacedGraphic = listPlacedGraphics.begin();
			while (iterPlacedGraphic != listPlacedGraphics.end())
			{
				Xml::HElement hPlacedGraphic = *(iterPlacedGraphic);
				int x = convertToInt(hPlacedGraphic->getAttribute("x"));
				int y = convertToInt(hPlacedGraphic->getAttribute("y"));
				VG::Point placedGrahpicLocation(x, y);

				Xml::ElementList listVectorGraphics = hPlacedGraphic->getChildElements();
				if (listVectorGraphics.size() == 0)
					continue;
				Xml::HElement hVectorGraphic = *(listVectorGraphics.begin());
				std::string strAttributeClosed = hVectorGraphic->getAttribute("closed");
				bool closed = (strAttributeClosed.compare("true") == 0) ? true : false;

				VG::HVectorGraphic vectorGraphic = std::make_shared<VG::VectorGraphic>();
				if (closed == true)
					vectorGraphic->closeShape();
				else
					vectorGraphic->openShape();

				Xml::ElementList listPoints = hVectorGraphic->getChildElements();
				auto iterPoint = listPoints.begin();

				while (iterPoint != listPoints.end())
				{
					Xml::HElement hChild = *(iterPoint);
					if (hChild->getName() == "Stroke")
					{
						std::string tip = hChild->getAttribute("tip");
						int size = convertToInt(hChild->getAttribute("size"));
						BitmapGraphics::Color color = convertToColor(hChild->getAttribute("color"));
						vectorGraphic->setStroke(tip, size, color);
						++iterPoint;
					}
					else
					{
						int pointX = convertToInt(hChild->getAttribute("x"));
						int pointY = convertToInt(hChild->getAttribute("y"));

						VG::Point point(pointX, pointY);

						vectorGraphic->addPoint(point);

						++iterPoint;
					}
				}

				PlacedGraphic placedGraphic;
				placedGraphic.setPlacementPoint(placedGrahpicLocation);
				placedGraphic.setGraphic(vectorGraphic);
				layer.pushBack(placedGraphic);

				++iterPlacedGraphic;
			}

			scene.pushBack(layer);
			++iterLayer;
		}

		return scene;
	}

	int SceneReader::convertToInt(const std::string& value)
	{
		std::stringstream s;
		s << value;
		int intVal;
		s >> intVal;
		return intVal;
	}

	BitmapGraphics::Color SceneReader::convertToColor(const std::string& value)
	{
		std::stringstream s;
		s << value;

		int intVal = 0;
		unsigned char c;
		int byteVal = 0;
		int count = 0;

		for (;;)
		{
			if (s)
			{
				byteVal = 0;
				s >> c;
				if (c >= 0x30 && c <= 0x39)
					byteVal = (int)c - 0x30;
				else if (c >= 0x41 && c <= 0x46)
					byteVal = (int)c - 0x41 + 10;

				intVal = (intVal << 4) + byteVal;
				if (++count >= 6)
					break;
			}
		}

		uint8_t b = (uint8_t)(intVal & 0x000000FF);
		uint8_t g = (uint8_t)((intVal & 0x0000FF00) >> 8);
		uint8_t r = (uint8_t)((intVal & 0X00FF0000) >> 16);

		BitmapGraphics::Color color(r, g, b);
		return color;
	}
}
