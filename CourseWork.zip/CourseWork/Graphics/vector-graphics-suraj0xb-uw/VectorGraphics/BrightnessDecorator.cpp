#include "BrightnessDecorator.h"
#include "ranged_number.h"

namespace BitmapGraphics
{
    BrightnessDecorator::BrightnessDecorator(HBitmapIterator iter, int intensity) :
            _brightnessIntensity(intensity), _originalIterator(iter)
    {
    }

    ScanLine& BrightnessDecorator::nextScanLine()
    {
        return _originalIterator->nextScanLine();
    }

    bool BrightnessDecorator::isEndOfImage()
    {
        return _originalIterator->isEndOfImage();
    }

    void BrightnessDecorator::nextPixel()
    {
        return _originalIterator->nextPixel();
    }

    bool BrightnessDecorator::isEndOfScanLine()
    {
        return _originalIterator->isEndOfScanLine();

    }


    uint32_t BrightnessDecorator::getBitmapWidth()
    {
        return _originalIterator->getBitmapWidth();
    }

    uint32_t BrightnessDecorator::getBitmapHeight()
    {
        return _originalIterator->getBitmapHeight();
    }

    Color BrightnessDecorator::getColor()
    {
        Color c = _originalIterator->getColor();
        
        int red = c.getRed() + _brightnessIntensity;
        int green = c.getGreen() + _brightnessIntensity;
        int blue = c.getBlue() + _brightnessIntensity;

        /*
        red = red + _brightnessIntensity;
        if (red > 255)
            red = 255;
        if (red < 0)
            red = 0;

        green = green + _brightnessIntensity;
        if (green > 255)
            green = 255;
        if (green < 0)
            green = 0;

        blue = blue + _brightnessIntensity;
        if (blue > 255)
            blue = 255;
        if (blue < 0)
            blue = 0;
        */
        using PixColor = ranged_number<int, 0, 255>;
        PixColor r(red);
        PixColor g(green);
        PixColor b(blue);

        Color newColor((uint8_t)((int)r), (uint8_t)((int)g), (uint8_t)((int)b));
        return newColor;
    }
}
