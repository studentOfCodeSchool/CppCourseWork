#pragma once

#include "BitmapIteratorDecorator.h"

namespace BitmapGraphics
{
    class BrightnessDecorator : public IBitmapIterator
    {
    public:
        BrightnessDecorator(HBitmapIterator iter , int intensity);
        virtual ~BrightnessDecorator() =default;

        BrightnessDecorator(const BrightnessDecorator& ) =default;
        BrightnessDecorator(BrightnessDecorator&& ) =default;
        BrightnessDecorator& operator=(const BrightnessDecorator& ) =default;
        BrightnessDecorator& operator=(BrightnessDecorator&& ) =default;

        ScanLine& nextScanLine() override;
        bool isEndOfImage() override;
        void nextPixel() override;
        bool isEndOfScanLine() override;
        Color getColor() override;
        uint32_t getBitmapWidth() override;
        uint32_t getBitmapHeight() override;

    private:
        int _brightnessIntensity = 0;
        HBitmapIterator _originalIterator;
    };
}
