#pragma once

#include <memory>

#include "Interface.h"
#include "Point.h"
#include "Color.h"
//#include "BasicCanvas.h"

namespace BitmapGraphics
{
    class Color;
    class Point;
    
    class ICanvas
    {
    public:
        ICanvas() = default;

        ICanvas(const ICanvas&) = delete;
        ICanvas(ICanvas&&) = delete;
        ICanvas& operator=(const ICanvas&) = delete;
        ICanvas& operator=(ICanvas&& ) = delete;

        virtual ~ICanvas() = default;
        virtual void setPixelColor(const VG::Point location, const Color color) = 0;
        virtual Color getPixelColor(const VG::Point location) const = 0;
        virtual int getWidth() const = 0;
        virtual int getHeight() const = 0;
        virtual HBitmapIterator createBitmapIterator() const = 0;
    };
}
