#include "TestHarness.h"

#include "CodecLibrary.h"
#include "BrightnessDecorator.h"
#include "ColorInversionDecorator.h"
#include "WindowsBitmapDecoder.h"
#include "WindowsBitmapEncoder.h"
#include "BitmapIterator.h"
#include <fstream>
#include <memory>

using namespace BitmapGraphics;

namespace
{
    const std::string msBmp{"image/x-ms-bmp"};
    
    std::shared_ptr<CodecLibrary> theCodecLibrary;

    void setUp()
    {
        theCodecLibrary.reset(new CodecLibrary);
        theCodecLibrary->registerEncoder(std::make_shared<WindowsBitmapEncoder>());
        theCodecLibrary->registerDecoder(std::make_shared<WindowsBitmapDecoder>());
    }

    void tearDown()
    {
        theCodecLibrary.reset();
    }
}

TEST(invalidDecoder, CodecLibrary)
{
    HBitmapDecoder decoder = std::make_shared<WindowsBitmapDecoder>();

    try
    {
        decoder->createIterator();
        CHECK(false);
    }
    catch (const std::exception& exc)
    {
        std::cout << exc.what() << std::endl;
        CHECK(true);
    }
}

TEST(invalidEncoder, CodecLibrary)
{
    HBitmapEncoder encoder = std::make_shared<WindowsBitmapEncoder>();

    try
    {
        std::ostringstream os{std::ios::binary};
        encoder->encodeToStream(os);
    }
    catch (const std::exception& exc)
    {
        std::cout << exc.what() << std::endl;
        CHECK(true);
    }
}

TEST(createEncoderViaMimeType, CodecLibrary)
{
    setUp();
    
    Bitmap nullBitmap{0, 0};
    HBitmapIterator iterator {nullBitmap.createIterator()};
    HBitmapEncoder encoder {theCodecLibrary->createEncoder(msBmp, iterator)};

    CHECK(dynamic_cast<WindowsBitmapEncoder*>(encoder.get()));

    tearDown();
}

TEST(failedCreateEncoderViaMimeType, CodecLibrary)
{
    setUp();
    
    Bitmap nullBitmap{0, 0};
    HBitmapIterator iterator {nullBitmap.createIterator()};
    
    try
    {
        HBitmapEncoder encoder {theCodecLibrary->createEncoder("image/unsupported-type", iterator)};
        CHECK(false);
    }
    catch (const std::exception& exc)
    {
        std::cout << exc.what() << std::endl;
        CHECK(true);
    }
    
    tearDown();
}

TEST(createDecoderViaMimeType, CodecLibrary)
{
    setUp();

    std::stringstream ss;
    HBitmapDecoder decoder {theCodecLibrary->createDecoder(msBmp, ss)};

    CHECK(dynamic_cast<WindowsBitmapDecoder*>(decoder.get()));

    tearDown();
}

TEST(createFailedDecoderViaMimeType, CodecLibrary)
{
    setUp();
    
    std::stringstream ss;
    
    try
    {
        HBitmapDecoder decoder {theCodecLibrary->createDecoder("image/unsupported-type", ss)};
        CHECK(false);
    }
    catch (const std::exception& exc)
    {
        std::cout << exc.what() << std::endl;
        CHECK(true);
    }

    tearDown();
}

TEST(createDecoderAutoDetermine, CodecLibrary)
{
    setUp();

    std::ifstream inFile{"basic.bmp", std::ios::binary};
    CHECK_EQUAL((bool)0, !inFile);
    HBitmapDecoder decoder {theCodecLibrary->createDecoder(inFile)};

    CHECK(decoder.get());
    CHECK(dynamic_cast<WindowsBitmapDecoder*>(decoder.get()));

    tearDown();
}

TEST(windowsBitmapDecodeEncode, CodecLibrary)
{
    setUp();

    std::ifstream inFile{"basic.bmp", std::ios::binary};
    CHECK_EQUAL((bool)0, !inFile);
    
    HBitmapDecoder decoder {theCodecLibrary->createDecoder(inFile)};
    HBitmapIterator iterator {decoder->createIterator()};
    
    CHECK(iterator.get());
    CHECK_EQUAL(100, iterator->getBitmapHeight());
    CHECK_EQUAL(100, iterator->getBitmapWidth());

    HBitmapEncoder encoder {theCodecLibrary->createEncoder(msBmp, iterator)};

    std::ofstream outFile{"output_basicCopy.bmp", std::ios::binary};
    encoder->encodeToStream(outFile);

    inFile.close();
    outFile.close();

    // TODO: file compare input/output
    std::ifstream srcBitmapStream("basic.bmp", std::ios::binary);
    WindowsBitmapHeader srcBitmapHeader(srcBitmapStream);
    Bitmap srcBitmap(srcBitmapHeader.getBitmapWidth(), srcBitmapHeader.getBitmapHeight(), srcBitmapStream);
    HBitmapIterator srcBitmapIter = srcBitmap.createIterator();

    std::ifstream dstBitmapStream("output_basicCopy.bmp", std::ios::binary);
    WindowsBitmapHeader dstBitmapHeader{ dstBitmapStream };
    Bitmap dstBitmap{ dstBitmapHeader.getBitmapWidth(), dstBitmapHeader.getBitmapHeight(), dstBitmapStream };
    HBitmapIterator dstBitmapIter = dstBitmap.createIterator();
    int numberOfScanLines = 0;

    CHECK_EQUAL(srcBitmapHeader.getFirstIdentifier(), dstBitmapHeader.getFirstIdentifier());
    CHECK_EQUAL(srcBitmapHeader.getSecondIdentifier(), dstBitmapHeader.getSecondIdentifier());
    CHECK_EQUAL(srcBitmapHeader.getFileSize(), dstBitmapHeader.getFileSize());
    CHECK_EQUAL(srcBitmapHeader.getRawImageByteOffset(), dstBitmapHeader.getRawImageByteOffset());
    CHECK_EQUAL(srcBitmapHeader.getInfoHeaderBytes(), dstBitmapHeader.getInfoHeaderBytes());
    CHECK_EQUAL(srcBitmapHeader.getBitmapWidth(), dstBitmapHeader.getBitmapWidth());
    CHECK_EQUAL(srcBitmapHeader.getBitmapHeight(), dstBitmapHeader.getBitmapHeight());
    CHECK_EQUAL(srcBitmapHeader.getNumberOfPanes(), dstBitmapHeader.getNumberOfPanes());
    CHECK_EQUAL(srcBitmapHeader.getBitsPerPixel(), dstBitmapHeader.getBitsPerPixel());
    CHECK_EQUAL(srcBitmapHeader.getCompressionType(), dstBitmapHeader.getCompressionType());

    // reads an extra character if char is vertical line feed, hence skip checks of last 3 params
    // as reuired to use peek and verify char not a control character
    // same while writing as well 
    // 
    CHECK_EQUAL(srcBitmapHeader.getHoriztonalPixelPerMeter(), dstBitmapHeader.getHoriztonalPixelPerMeter());
    CHECK_EQUAL(srcBitmapHeader.getVerticalPixelPerMeter(), dstBitmapHeader.getVerticalPixelPerMeter());
    CHECK_EQUAL(srcBitmapHeader.getNumberOfColors(), dstBitmapHeader.getNumberOfColors());
    CHECK_EQUAL(srcBitmapHeader.getNumberOfImportantColors(), dstBitmapHeader.getNumberOfImportantColors());

    int count = 1;

    while (!dstBitmapIter->isEndOfImage() && !srcBitmapIter->isEndOfImage())
    {
        int numberOfPixelsInScanLine = 0;
        while (!dstBitmapIter->isEndOfScanLine() && !srcBitmapIter->isEndOfScanLine())
        {
            Color srcColor = srcBitmapIter->getColor();
            Color dstColor = dstBitmapIter->getColor();

            CHECK_EQUAL(srcColor, dstColor);

            ++numberOfPixelsInScanLine;
            srcBitmapIter->nextPixel();
            dstBitmapIter->nextPixel();

            count++;
        }
        ++numberOfScanLines;

        CHECK_EQUAL(dstBitmapHeader.getBitmapWidth(), numberOfPixelsInScanLine);

        srcBitmapIter->nextScanLine();
        dstBitmapIter->nextScanLine();
    }

    CHECK_EQUAL(dstBitmapHeader.getBitmapHeight(), numberOfScanLines);

    srcBitmapStream.close();
    dstBitmapStream.close();

    tearDown();
}

TEST(brightnessDecoratorIterator, CodecLibrary)
{
    setUp();

    std::ifstream inFile{"basic.bmp", std::ios::binary};
    CHECK_EQUAL((bool)0, !inFile);
    
    HBitmapDecoder decoder {theCodecLibrary->createDecoder(inFile)};
    HBitmapIterator iterator {decoder->createIterator()};
    
    CHECK(iterator.get());
    CHECK_EQUAL(100, iterator->getBitmapHeight());
    CHECK_EQUAL(100, iterator->getBitmapWidth());

    HBitmapIterator brightnessIterator = std::make_shared<BrightnessDecorator>(iterator, 80);
    HBitmapEncoder encoder {theCodecLibrary->createEncoder(msBmp, brightnessIterator)};

    std::ofstream outFile{"output_basicBrightnessAdjusted.bmp", std::ios::binary};
    encoder->encodeToStream(outFile);

    inFile.close();
    outFile.close();

    // TODO: file compare input/output
    std::ifstream srcBitmapStream("basic.bmp", std::ios::binary);
    WindowsBitmapHeader srcBitmapHeader(srcBitmapStream);
    Bitmap srcBitmap(srcBitmapHeader.getBitmapWidth(), srcBitmapHeader.getBitmapHeight(), srcBitmapStream);
    HBitmapIterator srcBitmapIter = srcBitmap.createIterator();

    std::ifstream dstBitmapStream("output_basicBrightnessAdjusted.bmp", std::ios::binary);
    WindowsBitmapHeader dstBitmapHeader{ dstBitmapStream };
    Bitmap dstBitmap{ dstBitmapHeader.getBitmapWidth(), dstBitmapHeader.getBitmapHeight(), dstBitmapStream };
    HBitmapIterator dstBitmapIter = dstBitmap.createIterator();
    int numberOfScanLines = 0;

    CHECK_EQUAL(srcBitmapHeader.getFirstIdentifier(), dstBitmapHeader.getFirstIdentifier());
    CHECK_EQUAL(srcBitmapHeader.getSecondIdentifier(), dstBitmapHeader.getSecondIdentifier());
    CHECK_EQUAL(srcBitmapHeader.getFileSize(), dstBitmapHeader.getFileSize());
    CHECK_EQUAL(srcBitmapHeader.getRawImageByteOffset(), dstBitmapHeader.getRawImageByteOffset());
    CHECK_EQUAL(srcBitmapHeader.getInfoHeaderBytes(), dstBitmapHeader.getInfoHeaderBytes());
    CHECK_EQUAL(srcBitmapHeader.getBitmapWidth(), dstBitmapHeader.getBitmapWidth());
    CHECK_EQUAL(srcBitmapHeader.getBitmapHeight(), dstBitmapHeader.getBitmapHeight());
    CHECK_EQUAL(srcBitmapHeader.getNumberOfPanes(), dstBitmapHeader.getNumberOfPanes());
    CHECK_EQUAL(srcBitmapHeader.getBitsPerPixel(), dstBitmapHeader.getBitsPerPixel());
    CHECK_EQUAL(srcBitmapHeader.getCompressionType(), dstBitmapHeader.getCompressionType());

    // reads an extra character if char is vertical line feed, hence skip checks of last 3 params
    // as reuired to use peek and verify char not a control character
    // same while writing as well 
    // 
    CHECK_EQUAL(srcBitmapHeader.getHoriztonalPixelPerMeter(), dstBitmapHeader.getHoriztonalPixelPerMeter());
    CHECK_EQUAL(srcBitmapHeader.getVerticalPixelPerMeter(), dstBitmapHeader.getVerticalPixelPerMeter());
    CHECK_EQUAL(srcBitmapHeader.getNumberOfColors(), dstBitmapHeader.getNumberOfColors());
    CHECK_EQUAL(srcBitmapHeader.getNumberOfImportantColors(), dstBitmapHeader.getNumberOfImportantColors());

    while (!dstBitmapIter->isEndOfImage() && !srcBitmapIter->isEndOfImage())
    {
        int numberOfPixelsInScanLine = 0;
        while (!dstBitmapIter->isEndOfScanLine() && !srcBitmapIter->isEndOfScanLine())
        {
            Color srcColor = srcBitmapIter->getColor();
            Color dstColor = dstBitmapIter->getColor();

            int red = srcColor.getRed() + 80;
            if (red > 255)
                red = 255;
            if (red < 0)
                red = 0;

            int green = srcColor.getGreen() + 80;
            if (green > 255)
                green = 255;
            if (green < 0)
                green = 0;

            int blue = srcColor.getBlue() + 80;
            if (blue > 255)
                blue = 255;
            if (blue < 0)
                blue = 0;

            Color adjColor((uint8_t)red, (int8_t)green, (uint8_t)blue);
            CHECK_EQUAL(adjColor, dstColor);

            ++numberOfPixelsInScanLine;
            srcBitmapIter->nextPixel();
            dstBitmapIter->nextPixel();
        }
        ++numberOfScanLines;

        CHECK_EQUAL(dstBitmapHeader.getBitmapWidth(), numberOfPixelsInScanLine);

        srcBitmapIter->nextScanLine();
        dstBitmapIter->nextScanLine();
    }

    CHECK_EQUAL(dstBitmapHeader.getBitmapHeight(), numberOfScanLines);

    srcBitmapStream.close();
    dstBitmapStream.close();

    tearDown();
}

TEST(colorInvertDecoratorIterator, CodecLibrary)
{
    setUp();

    std::ifstream inFile{"basic.bmp", std::ios::binary};
    CHECK_EQUAL((bool)0, !inFile);
    
    HBitmapDecoder decoder {theCodecLibrary->createDecoder(inFile)};
    HBitmapIterator iterator {decoder->createIterator()};
    
    CHECK(iterator.get());
    CHECK_EQUAL(100, iterator->getBitmapHeight());
    CHECK_EQUAL(100, iterator->getBitmapWidth());

    HBitmapIterator colorInvertIterator = std::make_shared<ColorInversionDecorator>(iterator);
    HBitmapEncoder encoder {theCodecLibrary->createEncoder(msBmp, colorInvertIterator)};

    std::ofstream outFile{"output_basicColorInvert.bmp", std::ios::binary};
    encoder->encodeToStream(outFile);
    
    inFile.close();
    outFile.close();

    // TODO: file compare input/output
    std::ifstream srcBitmapStream("basic.bmp", std::ios::binary);
    WindowsBitmapHeader srcBitmapHeader(srcBitmapStream);
    Bitmap srcBitmap(srcBitmapHeader.getBitmapWidth(), srcBitmapHeader.getBitmapHeight(), srcBitmapStream);
    HBitmapIterator srcBitmapIter = srcBitmap.createIterator();

    std::ifstream dstBitmapStream("output_basicColorInvert.bmp", std::ios::binary);
    WindowsBitmapHeader dstBitmapHeader{ dstBitmapStream };
    Bitmap dstBitmap{ dstBitmapHeader.getBitmapWidth(), dstBitmapHeader.getBitmapHeight(), dstBitmapStream };
    HBitmapIterator dstBitmapIter = dstBitmap.createIterator();
    int numberOfScanLines = 0;

    CHECK_EQUAL(srcBitmapHeader.getFirstIdentifier(), dstBitmapHeader.getFirstIdentifier());
    CHECK_EQUAL(srcBitmapHeader.getSecondIdentifier(), dstBitmapHeader.getSecondIdentifier());
    CHECK_EQUAL(srcBitmapHeader.getFileSize(), dstBitmapHeader.getFileSize());
    CHECK_EQUAL(srcBitmapHeader.getRawImageByteOffset(), dstBitmapHeader.getRawImageByteOffset());
    CHECK_EQUAL(srcBitmapHeader.getInfoHeaderBytes(), dstBitmapHeader.getInfoHeaderBytes());
    CHECK_EQUAL(srcBitmapHeader.getBitmapWidth(), dstBitmapHeader.getBitmapWidth());
    CHECK_EQUAL(srcBitmapHeader.getBitmapHeight(), dstBitmapHeader.getBitmapHeight());
    CHECK_EQUAL(srcBitmapHeader.getNumberOfPanes(), dstBitmapHeader.getNumberOfPanes());
    CHECK_EQUAL(srcBitmapHeader.getBitsPerPixel(), dstBitmapHeader.getBitsPerPixel());
    CHECK_EQUAL(srcBitmapHeader.getCompressionType(), dstBitmapHeader.getCompressionType());

    // reads an extra character if char is vertical line feed, hence skip checks of last 3 params
    // as reuired to use peek and verify char not a control character
    // same while writing as well 
    // 
    CHECK_EQUAL(srcBitmapHeader.getHoriztonalPixelPerMeter(), dstBitmapHeader.getHoriztonalPixelPerMeter());
    CHECK_EQUAL(srcBitmapHeader.getVerticalPixelPerMeter(), dstBitmapHeader.getVerticalPixelPerMeter());
    CHECK_EQUAL(srcBitmapHeader.getNumberOfColors(), dstBitmapHeader.getNumberOfColors());
    CHECK_EQUAL(srcBitmapHeader.getNumberOfImportantColors(), dstBitmapHeader.getNumberOfImportantColors());

    while (!dstBitmapIter->isEndOfImage() && !srcBitmapIter->isEndOfImage())
    {
        int numberOfPixelsInScanLine = 0;
        while (!dstBitmapIter->isEndOfScanLine() && !srcBitmapIter->isEndOfScanLine())
        {
            Color srcColor = srcBitmapIter->getColor();
            Color dstColor = dstBitmapIter->getColor();

            Color invColor(~srcColor.getRed(), ~srcColor.getGreen(), ~srcColor.getBlue());
            CHECK_EQUAL(invColor, dstColor);

            ++numberOfPixelsInScanLine;
            srcBitmapIter->nextPixel();
            dstBitmapIter->nextPixel();
        }
        ++numberOfScanLines;

        CHECK_EQUAL(dstBitmapHeader.getBitmapWidth(), numberOfPixelsInScanLine);

        srcBitmapIter->nextScanLine();
        dstBitmapIter->nextScanLine();
    }

    CHECK_EQUAL(dstBitmapHeader.getBitmapHeight(), numberOfScanLines);

    srcBitmapStream.close();
    dstBitmapStream.close();

    tearDown();
}

TEST(doubleDecorator, CodecLibrary)
{
    setUp();

    std::ifstream inFile{"basic.bmp", std::ios::binary};
    CHECK_EQUAL((bool)0, !inFile);
    
    HBitmapDecoder decoder {theCodecLibrary->createDecoder(inFile)};
    HBitmapIterator iterator {decoder->createIterator()};
    
    CHECK(iterator.get());
    CHECK_EQUAL(100, iterator->getBitmapHeight());
    CHECK_EQUAL(100, iterator->getBitmapWidth());

    HBitmapIterator colorInvertIterator = std::make_shared<ColorInversionDecorator>(iterator);
    HBitmapIterator darkenColorInvertIterator = std::make_shared<BrightnessDecorator>(colorInvertIterator, -50);

    HBitmapEncoder encoder {theCodecLibrary->createEncoder(msBmp, darkenColorInvertIterator)};
        
    std::ofstream outFile{"output_darkInverted.bmp", std::ios::binary};
    encoder->encodeToStream(outFile);
    
    inFile.close();
    outFile.close();

    // TODO: file compare input/output

    std::ifstream srcBitmapStream("basic.bmp", std::ios::binary);
    WindowsBitmapHeader srcBitmapHeader(srcBitmapStream);
    Bitmap srcBitmap(srcBitmapHeader.getBitmapWidth(), srcBitmapHeader.getBitmapHeight(), srcBitmapStream);
    HBitmapIterator srcBitmapIter = srcBitmap.createIterator();

    std::ifstream dstBitmapStream("output_darkInverted.bmp", std::ios::binary);
    WindowsBitmapHeader dstBitmapHeader{ dstBitmapStream };
    Bitmap dstBitmap{ dstBitmapHeader.getBitmapWidth(), dstBitmapHeader.getBitmapHeight(), dstBitmapStream };
    HBitmapIterator dstBitmapIter = dstBitmap.createIterator();
    int numberOfScanLines = 0;

    CHECK_EQUAL(srcBitmapHeader.getFirstIdentifier(), dstBitmapHeader.getFirstIdentifier());
    CHECK_EQUAL(srcBitmapHeader.getSecondIdentifier(), dstBitmapHeader.getSecondIdentifier());
    CHECK_EQUAL(srcBitmapHeader.getFileSize(), dstBitmapHeader.getFileSize());
    CHECK_EQUAL(srcBitmapHeader.getRawImageByteOffset(), dstBitmapHeader.getRawImageByteOffset());
    CHECK_EQUAL(srcBitmapHeader.getInfoHeaderBytes(), dstBitmapHeader.getInfoHeaderBytes());
    CHECK_EQUAL(srcBitmapHeader.getBitmapWidth(), dstBitmapHeader.getBitmapWidth());
    CHECK_EQUAL(srcBitmapHeader.getBitmapHeight(), dstBitmapHeader.getBitmapHeight());
    CHECK_EQUAL(srcBitmapHeader.getNumberOfPanes(), dstBitmapHeader.getNumberOfPanes());
    CHECK_EQUAL(srcBitmapHeader.getBitsPerPixel(), dstBitmapHeader.getBitsPerPixel());
    CHECK_EQUAL(srcBitmapHeader.getCompressionType(), dstBitmapHeader.getCompressionType());

    // reads an extra character if char is vertical line feed, hence skip checks of last 3 params
    // as reuired to use peek and verify char not a control character
    // same while writing as well 
    // 
    CHECK_EQUAL(srcBitmapHeader.getHoriztonalPixelPerMeter(), dstBitmapHeader.getHoriztonalPixelPerMeter());
    CHECK_EQUAL(srcBitmapHeader.getVerticalPixelPerMeter(), dstBitmapHeader.getVerticalPixelPerMeter());
    CHECK_EQUAL(srcBitmapHeader.getNumberOfColors(), dstBitmapHeader.getNumberOfColors());
    CHECK_EQUAL(srcBitmapHeader.getNumberOfImportantColors(), dstBitmapHeader.getNumberOfImportantColors());

    while (!dstBitmapIter->isEndOfImage() && !srcBitmapIter->isEndOfImage())
    {
        int numberOfPixelsInScanLine = 0;
        while (!dstBitmapIter->isEndOfScanLine() && !srcBitmapIter->isEndOfScanLine())
        {
            Color srcColor = srcBitmapIter->getColor();
            Color dstColor = dstBitmapIter->getColor();

            uint8_t r = srcColor.getRed();
            uint8_t g = srcColor.getGreen();
            uint8_t b = srcColor.getBlue();

            r = ~r;
            g = ~g;
            b = ~b;

            int red = r;
            int green = g;
            int blue = b;

            red -= 50;
            if (red > 255)
                red = 255;
            if (red < 0)
                red = 0;

            green -= 50;
            if (green > 255)
                green = 255;
            if (green < 0)
                green = 0;

            blue -= 50;
            if (blue > 255)
                blue = 255;
            if (blue < 0)
                blue = 0;

            r = (uint8_t)red;
            b = (uint8_t)blue;
            g = (int8_t)green;


            Color adjColor(r, g, b);
            CHECK_EQUAL(adjColor, dstColor);

            ++numberOfPixelsInScanLine;
            srcBitmapIter->nextPixel();
            dstBitmapIter->nextPixel();
        }
        ++numberOfScanLines;

        CHECK_EQUAL(dstBitmapHeader.getBitmapWidth(), numberOfPixelsInScanLine);

        srcBitmapIter->nextScanLine();
        dstBitmapIter->nextScanLine();
    }

    CHECK_EQUAL(dstBitmapHeader.getBitmapHeight(), numberOfScanLines);

    srcBitmapStream.close();
    dstBitmapStream.close();

    tearDown();
}

