#include "TestHarness.h"

#include "ranged_number.h"


TEST(cTor, ranged_number)
{
    //Will not compile, otherwise behavior becomes undefined.
    //ranged_number<short, 12, 1> grade{ 2 };

    const ranged_number<short, 1, 12> grade(5);
    CHECK_EQUAL(5, static_cast<short>(grade));
}

TEST(preIncrement, ranged_number)
{
    ranged_number<short, 1, 12> grade(5);
    CHECK_EQUAL(5, static_cast<short>(grade));

    ++grade;
    CHECK_EQUAL(6, static_cast<short>(grade));
}

TEST(preIncrementConstraint, ranged_number)
{
    ranged_number<short, 1, 12> grade(12);
    CHECK_EQUAL(12, static_cast<short>(grade));

    ++grade;
    CHECK_EQUAL(12, static_cast<short>(grade));
}

TEST(postIncrementConstraint, ranged_number)
{
    ranged_number<short, 1, 12> grade(12);
    CHECK_EQUAL(12, static_cast<short>(grade));

    const auto result = grade++;

    CHECK_EQUAL(12, static_cast<short>(grade));
    CHECK_EQUAL(12, static_cast<short>(result));
}

TEST(preDecrementConstraint, ranged_number)
{
    ranged_number<short, 1, 12> grade(1);
    CHECK_EQUAL(1, static_cast<short>(grade));

    --grade;
    CHECK_EQUAL(1, static_cast<short>(grade));
}

TEST(postDecrementConstraint, ranged_number)
{
    ranged_number<short, 1, 12> grade(1);
    CHECK_EQUAL(1, static_cast<short>(grade));

    const auto result = grade--;
    CHECK_EQUAL(1, static_cast<short>(result));
    CHECK_EQUAL(1, static_cast<short>(grade));
}

using Grade = ranged_number<int, 1, 12>;
TEST(operatorPlus, ranged_number)
{
    Grade grade{ 5 };

    grade = grade + Grade{ 5 };
    CHECK_EQUAL(10, static_cast<int>(grade));

    grade = grade + Grade{ 5 };
    CHECK_EQUAL(12, static_cast<int>(grade));
}

TEST(operatorPlusEquals, ranged_number)
{
    Grade grade{ 5 };

    grade += 5;
    CHECK_EQUAL(10, static_cast<int>(grade));

    grade += 5;
    CHECK_EQUAL(12, static_cast<int>(grade));
}

TEST(wrapAroundUpperLimitOfUnsignedType, ranged_number)
{
    ranged_number<uint8_t, 1, 250> wrapable{ 249 };

    wrapable += 10;

    CHECK_EQUAL(250, static_cast<uint8_t>(wrapable));
}

TEST(wrapAroundUpperLimitOfSignedType, ranged_number)
{
    ranged_number<int8_t, 1, 120> wrapable{ 119 };

    wrapable += 10;

    CHECK_EQUAL(120, static_cast<int8_t>(wrapable));
}

TEST(addingNegativeSignedType, ranged_number)
{
    ranged_number<int8_t, -5, 5> range{ 1 };

    range += -4;

    CHECK_EQUAL(-3, static_cast<int8_t>(range));

    range += -4;

    CHECK_EQUAL(-5, static_cast<int8_t>(range));
}

TEST(wrapAroundLowerLimitOfSignedType, ranged_number)
{
    ranged_number<int8_t, -120, 5> wrapable{ -119 };

    wrapable += -10;

    CHECK_EQUAL(-120, static_cast<int8_t>(wrapable));
}

TEST(preDecrementNotAtLowerLimit, ranged_number)
{
    ranged_number<int32_t, 5, 10> value(6);

    --value;

    CHECK_EQUAL(5, static_cast<int32_t>(value));
}

TEST(postDecrementNotAtLowerLimit, ranged_number)
{
    ranged_number<int32_t, 5, 10> value(6);

    const auto result = value--;

    CHECK_EQUAL(6, static_cast<int32_t>(result));
    CHECK_EQUAL(5, static_cast<int32_t>(value));
}

TEST(preIncrementNotAtUpperLimit, ranged_number)
{
    ranged_number<int32_t, 5, 10> value(6);

    ++value;

    CHECK_EQUAL(7, static_cast<int32_t>(value));
}

TEST(postIncrementNotAtUpperLimit, ranged_number)
{
    ranged_number<int32_t, 5, 10> value(6);

    const auto result = value++;

    CHECK_EQUAL(6, static_cast<int32_t>(result));
    CHECK_EQUAL(7, static_cast<int32_t>(value));
}
