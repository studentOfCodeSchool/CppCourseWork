//
//  main.cpp
//  Assignment 1
//

#include "TestHarness.h"

int main()
{
    TestResult tr;
    TestRegistry::runAllTests(tr);

    return 0;
}
