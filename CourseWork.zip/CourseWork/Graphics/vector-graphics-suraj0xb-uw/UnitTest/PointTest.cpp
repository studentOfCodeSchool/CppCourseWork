//
//  PointTest.cpp
//  Assignment1
//
//  Created by Chris Elderkin on 4/26/15.
//  Copyright (c) 2015 Chris Elderkin. All rights reserved.
//

#include "Point.h"
#include "TestHarness.h"

#include <utility>


TEST(equality, Point)
{
    CHECK_EQUAL(VG::Point(1, 2), VG::Point(1, 2));
}

TEST(inequality, Point)
{
    CHECK(VG::Point(1, 2) != VG::Point(3, 4));
}

TEST(constexprPoint, Point)
{
    constexpr int i = VG::Point{4, 5}.getX();

    CHECK_EQUAL(4, i);
}

// ADD MORE TESTS HERE!
TEST(getX, Point)
{
    constexpr int xpos = VG::Point{4, 5}.getX();

    CHECK_EQUAL(4, xpos);
}

TEST(getY, Point)
{
    constexpr int ypos = VG::Point{7, 9}.getY();

    CHECK_EQUAL(9, ypos);
}

TEST(copyConstructor, Point)
{
    VG::Point pt = VG::Point{10, 20};

    VG::Point ptTwo(pt);

    CHECK_EQUAL(pt.getX(), ptTwo.getX());
    CHECK_EQUAL(pt.getY(), ptTwo.getY());
}

TEST(moveConstructor, Point)
{
    auto pt = std::make_unique<VG::Point>(20, 40);

    VG::Point ptTwo(std::move(*(pt.release())));

    CHECK_EQUAL(20, ptTwo.getX());
    CHECK_EQUAL(40, ptTwo.getY());

}

TEST(copyAssignmentOperator, Point)
{
    VG::Point ptOne = VG::Point{30, 50};
    VG::Point ptTwo = VG::Point{1, 2};

    ptTwo = ptOne;

    CHECK_EQUAL(ptTwo, ptOne);

    CHECK_EQUAL(30, ptTwo.getX());
    CHECK_EQUAL(50, ptTwo.getY());
    
    CHECK_EQUAL(30, ptOne.getX());
    CHECK_EQUAL(50, ptTwo.getY());
}

TEST(moveAssignmentOperator, Point)
{
    auto ptOne = std::make_unique<VG::Point>(40, 60);
    VG::Point ptTwo = VG::Point{1, 2};

    ptTwo = std::move(*(ptOne.release()));

    CHECK_EQUAL(40, ptTwo.getX());
    CHECK_EQUAL(60, ptTwo.getY());

}

