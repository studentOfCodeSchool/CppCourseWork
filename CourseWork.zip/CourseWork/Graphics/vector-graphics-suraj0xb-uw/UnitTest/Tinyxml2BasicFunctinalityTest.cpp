#include "TestHarness.h"

#include "tinyxml2.h"

using namespace tinyxml2;

TEST(tinyxml2, TestOne)
{
    XMLDocument doc;

    doc.SaveFile("foo.xml");
}
