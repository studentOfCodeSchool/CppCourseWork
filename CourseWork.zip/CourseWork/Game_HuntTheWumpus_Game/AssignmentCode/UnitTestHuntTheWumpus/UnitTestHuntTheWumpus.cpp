#include "TestHarness.h"

int main()
{
    TestResult tr;
    TestRegistry::runAllTests(tr);

    return 0;
}
