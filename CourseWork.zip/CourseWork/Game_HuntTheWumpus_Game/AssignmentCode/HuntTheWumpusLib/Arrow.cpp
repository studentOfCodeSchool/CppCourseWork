#include "Arrow.h"

#include "UserNotification.h"
#include "Context.h"
#include "RandomProvider.h"
#include "Cave.h"

namespace HuntTheWumpus
{
    Arrow::Arrow(const int arrowInstance, Context &providers)
        : Denizen(DenizenIdentifier{ Category::Arrow, arrowInstance }, { false, true, true, false, false }, providers)
    {       
    }

    bool Arrow::ObserveCaveEntrance(const std::shared_ptr<Denizen>& trigger)
    {
        if (trigger->Properties().m_reportMovement == false)
        {
            const auto cave = m_cave.lock();
            const int caveId = cave->GetCaveId();
            m_providers.m_notification.Notify(UserNotification::Notification::ObserveArrowPath, caveId);
        }

        return false;
    }
}