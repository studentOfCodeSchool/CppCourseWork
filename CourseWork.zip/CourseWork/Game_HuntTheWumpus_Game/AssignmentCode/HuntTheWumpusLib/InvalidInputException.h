#pragma once

#include <exception>
#include <string>

namespace HuntTheWumpus
{

	class InvalidInputException : public std::exception
	{
	public:
		InvalidInputException(const std::string str) : std::exception(str.c_str())
		{ }

		InvalidInputException() = delete;
		~InvalidInputException() = default;

		InvalidInputException(const InvalidInputException& src) = default;
		InvalidInputException(InvalidInputException&& src) = default;

		InvalidInputException& operator=(const InvalidInputException& rhs) = default;
		InvalidInputException& operator=(InvalidInputException&& rhs) = default;
	};
}

